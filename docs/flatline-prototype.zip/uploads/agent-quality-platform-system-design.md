# Agent 工作系统质量平台 · 完整系统设计

> 系统设计文档 · v0.2 · 2026-08-17
> 配套文档：《Agent 工作系统质量分析与持续优化平台》产品设计 v0.2

## 0. 文档定位

本文是整套系统的完整技术设计，覆盖本地客户端（daemon、存储、检测引擎、Web UI、CLI、MCP）、桌面壳、官方后台服务（账户、设备、团队、同步、聚合、群体参考、托管 AI、订阅）以及贯穿两端的数据模型、同步协议、隐私与安全边界。实施排期不属于本文范围。

---

## 1. 设计不变量

以下七条约束所有组件，任何设计冲突以此裁决：

1. **证据可重建**：每一条事实、finding 和建议都能追溯到原始事件、配置快照或明确的计算过程。
2. **不确定性显式化**：`observed / derived / inferred / ai_analysis / user_asserted / unknown` 六态贯穿全库，不同认识论等级不得混成一个分数。
3. **原始数据本地优先**：本地客户端是完整事实来源；后台不假设自己拥有任何未经授权的本地数据；用户不登录获得完整个人价值。
4. **变化点可陈述，因果只能暗示**：环境/版本变化是检测的维度而非独立功能；任何组件不得从变化点直接推导"变差了"。
5. **音量与证据等级挂钩**：observed 大声说，derived 正常说，inferred 必须带分母、构成与反例，AI 分析永远署名且逐条引用证据。
6. **缺失不等于零**：数据不足输出 unknown，不可见不得被统计为未发生；所有指标携带观测等级。
7. **只读与非阻断**：对 harness 数据源永远只读；不拦截任务、不阻断流程、不自动改写任何用户资产；写操作必须显式授权。

---

## 2. 系统全景

```mermaid
flowchart TD
    subgraph local["本地客户端（完整事实来源）"]
        AD["Source Adapters"] --> CES["Canonical Event Store"]
        SNAP["Asset Snapshotter"] --> AR["Asset Registry"]
        CES & AR --> EBR["Effective Bundle Resolver"]
        CES & EBR --> DQE["Deterministic Quality Engine"]
        DQE --> FIN["Findings + Evidence"]
        FIN --> OBS["Change Tracker / Observation Windows"]
        FIN -.-> AI["AI Analysis Runtime"]
        CES & AR & FIN & OBS --> API["Local API（loopback）"]
    end

    API --> UI["嵌入式 Web UI"]
    API --> CLI["CLI"]
    API --> MCP["只读 MCP"]
    SHELL["桌面壳（Tauri）"] -->|"生命周期管理 + 显示 UI"| API

    API --> PG["Privacy Gateway（唯一出口）"]
    PG <--> BE["官方后台"]

    subgraph BE["官方后台服务"]
        ACC["Account & Device"]
        ORG["Org / Team / RBAC"]
        SYNC["Sync Service"]
        AGG["Aggregate Ingestion"]
        REF["Reference Engine"]
        MAI["Managed AI"]
        SUB["Subscription / Entitlement"]
    end
```

两端不是两个产品，而是一个产品的两个运行部分：本地客户端掌握原始轨迹、资产内容和个人分析；官方后台掌握账户、组织、授权、同步结果和群体参考。本地界面根据登录与授权状态合并两端结果，用户始终在同一套界面和对象模型中工作。任何数据离开本机必须且只能经过隐私网关。

---

## 3. 技术选型与运行形态

### 3.1 语言与运行时

**内核语言：Go。**理由：并发模型（goroutine + channel）天然匹配"文件监听 + 增量摄取 + API 服务"的常驻负载；交叉编译与 `embed` 支持"单二进制内嵌 SPA"的交付形态；fsnotify 生态成熟；AgentsView 已验证 Go + 内嵌 SPA 交付模型在同类产品上可行。

**硬性决策：SQLite 驱动使用 `modernc.org/sqlite`（纯 Go），禁用 `mattn/go-sqlite3`（CGO）。**CGO 会破坏交叉编译的零依赖性，动摇单二进制承诺；纯 Go 驱动的性能（本场景为万级 session、百万级事件的单机负载）完全够用。

备选路线：若团队转向 Rust 全栈（内核 + Tauri 同语言），交付模型不变，本文其余设计不受影响。

### 3.2 进程拓扑

- **daemon 是唯一数据属主。**Web UI、CLI、桌面壳、MCP 全部是它的客户端，通过 loopback HTTP/SSE 访问；不存在第二条数据通路。
- 两种运行模式共享同一存储：`serve`（前台，开发与临时使用）、`daemon`（后台常驻 + 文件监听 + 定时任务）。
- 单实例保证：`~/.<product>/daemon.lock` 文件锁；启动信息写入 `~/.<product>/daemon.json`（端口、PID、启动时间、API token）。
- 网络：默认仅绑定 `127.0.0.1`，校验 Host/Origin；本地 API 使用启动时生成的 token 鉴权（防止本机其他进程的未授权访问）；对外暴露必须显式配置并启用认证。
- 数据源目录（`~/.claude/`、`~/.codex/`、dsh 日志、资产目录）一律只读访问，绝不写入、移动或锁定。
- 空闲策略：无客户端连接且无新数据达到阈值时长后，daemon 可配置为自动降频或退出（由壳或 systemd/launchd 按需拉起）。

### 3.3 桌面壳

**框架：Tauri v2，daemon 以 sidecar 形式打包。**壳层职责严格限定，不复制任何业务逻辑：

| 职责 | 设计 |
| --- | --- |
| 安装与引导 | 首启向导：展示将读取的目录清单与隐私说明 → 用户确认 → 触发首次导入。macOS 上若用户项目位于受 TCC 保护目录（Desktop/Documents），引导授予访问权限 |
| daemon 生命周期 | 启动时读 `daemon.json` → `/healthz` 探活 → 存活则 attach；不存活则启动 sidecar。壳退出时按用户配置决定 daemon 常驻或随壳退出 |
| 版本协商 | 壳与 daemon 可能由不同渠道安装（brew/官网/壳内更新）。握手交换 API schema 版本；壳发现 daemon 过旧且由自己管理时，替换二进制并热重启；daemon 更新与壳更新是两条独立通道 |
| 系统集成 | 托盘、开机自启、系统通知（订阅 daemon 的 SSE finding 流并转为系统通知，频率受用户配置的"开口时刻"策略约束） |
| 自动更新 | 壳走 Tauri updater；daemon 由壳按签名版本清单更新。CLI 独立安装的 daemon 不受壳管理 |

壳内显示的界面就是 daemon 的嵌入式 Web UI（webview 指向 loopback 地址），不存在第二套界面实现。CLI、浏览器、桌面三种入口看到完全相同的产品。

### 3.4 Web UI 与实时通道

- 嵌入式 SPA，构建产物经 `embed` 编译进二进制；无外部静态资源依赖。
- REST/JSON 为查询协议；SSE 为增量推送（导入进度、新 finding、观察窗结算、adapter health 变化）。检测结果是天然的单向事件流，不引入 WebSocket 的连接管理复杂度。
- 信息架构**按问题索引**：一级入口是高频真实问题（这个项目为什么费劲 / 上次修改有没有用 / 成本为什么变高 / 这个 session 为什么翻车 / 哪些资产在拖后腿 / 环境变化后我受影响了吗），每个问题绑定固定的 detector 集 + 对比维度 + 视图。Sessions / Assets / Findings / Compare / Improvements / Reference 作为二级浏览面。
- 每个数据对象携带来源标签：`Local / Synced / Team / Reference / Managed AI`。

### 3.5 CLI 与 MCP

- CLI 与 UI 共享同一 local API：扫描、搜索、报告导出、CI 注释生成、健康诊断。
- MCP server 提供**只读**查询（session 事实、已确认经验、资产状态），供用户的 agent 在任务中调用；任何写入配置的能力不经此接口暴露，写操作必须走带显式授权的独立路径。

---

## 4. 本地数据面组件设计

### 4.1 Source Adapters（数据源适配器）

每个适配器声明一张**字段矩阵**：能提供 canonical 契约的哪些字段、观测等级（Exact / Partial / Inferred）、适用 harness 版本范围。矩阵驱动 UI 的"数据覆盖与缺失"展示，并作为 detector required-fields 检查的依据。

已实证确认的输入能力（2026-08 调研，依据见附录 A）：

| 信号 | Claude Code | Codex | 观测等级 |
| --- | --- | --- | --- |
| 工具调用 + 结果（id、input、exit code） | transcript `tool_use` / `tool_result` 块 | rollout `FunctionCall` / `FunctionCallOutput` | Exact |
| skill 显式调用 | `tool_use` 且 `name == "Skill"`，带稳定调用 id | 无原生事件，靠 `exec_command` 参数路径正则 | CC: Exact / Codex: Inferred |
| harness 版本 | 每行自带 `version` 字段 | SessionMeta / TurnContext | Exact |
| 模型、sandbox、approval、cwd、permission profile | assistant 条目 + 会话元数据 | `TurnContextItem`（持久化） | Exact |
| AGENTS.md / 指令注入内容 | 消息内嵌 system-reminder 类块 | 拼装进 user instructions 的持久化消息 | Exact（内容级） |
| 候选集合（当时模型看到哪些 skill / 工具） | 系统提示不落盘 | `AdditionalTools` 被持久化策略显式排除 | 日志中不存在 → 由快照器/hook 补 |
| token / 成本 | `message.usage` | TokenCount 事件 | Exact（CC 有已知 output 低估 bug，成本注记） |

工程纪律：

- 每个适配器附带**真实脱敏 fixture 库**，按 harness 版本归档，CI 全量回归——这是对官方明确警告的"格式为内部实现、随版本变化"的直接应对。
- 内置版本探测（CC 读每行 `version`；Codex 读 SessionMeta），未知版本降级解析并在 adapter health 上报，不静默产出错误数据。
- 解析失败的行记录 locator 并计数，绝不吞掉；`覆盖率 = 成功规范化行数 / 总行数` 是一等健康指标。
- 适配器集合：Claude Code、Codex、DeepSeek Harness 原生适配器；AgentsView SQLite 兼容适配器（复用其解析成果，MIT 许可；不作为事实模型——其归一化以 session 浏览为中心，丢失资产暴露与上下文来源）；OTel/JSONL 通用入口（企业与自定义 harness 接入）。
- dsh 深度适配：`dsh-quality-observer` 插件经官方事件与服务 seam 捕获 session/turn/step 生命周期、system prompt section 与 context injection 来源、skill catalog 与加载、tool schema 暴露、profile/bundle/patch 状态、compaction 与 context pressure。dsh 是唯一能提供 Exact 级候选集的源，其数据同时充当**校准集**：用它标定 CC/Codex 上推断型 detector 的精度。

### 4.2 Asset Snapshotter（资产快照器）

**定位：观测升级器。**候选集合在 CC/Codex 日志中不存在，唯一补法是产品自己成为记录者。

- 监听范围由各 harness 适配器声明（`~/.claude/skills/`、`.claude/skills/`、`CLAUDE.md`、`AGENTS.md` 层级、rules / workflows / hooks / 插件配置等），不硬编码。
- 内容哈希驱动，仅变更时创建新 `AssetVersion`；记录路径、scope、git commit 或 dirty 标记。
- 时间语义：`AssetVersion` 携带 `[valid_from, valid_to)`；session 与资产的关联 = session 时间戳落入的版本区间。
- **观测等级跃迁规则**：安装前的历史 session，offered 集只能按当前目录回推，标 Inferred 且 UI 明示；安装后由快照记录，标 Derived；启用可选 hook 后 session 启动瞬间清单直接落盘，标 Exact。数据质量随使用时长单调上升，该特性显式呈现给用户。

### 4.3 Canonical Event Store（规范事件存储）

```json
{
  "event_id": "stable-id（源位置与内容哈希派生，重扫幂等）",
  "session_id": "...",
  "sequence": 42,
  "timestamp": "2026-08-17T10:00:00Z",
  "kind": "tool.result",
  "actor": "main-agent | subagent:<id>",
  "producer": "claude-code | codex | dsh",
  "payload_ref": "local://<file>#<line>",
  "normalized": { "tool_name": "Bash", "exit_code": 1, "duration_ms": 812 },
  "observability": "exact | partial | inferred",
  "adapter": { "name": "claude-code", "version": "0.1.0" }
}
```

- append-only；重扫幂等（event_id 由源派生）。
- 原始 payload 不复制入库，只存必要 normalized 字段、哈希与 locator；证据下钻按 locator 回读原文件。这同时是隐私边界：canonical 库默认不含完整 transcript 文本。
- **EnvironmentChanged 是一等事件**：Effective Bundle 任何一维变化（harness 版本、模型、资产哈希、profile/mode、插件集）写入锚点事件。它不是 finding，是时间轴分割点，供 detector 定义参照窗口。

### 4.4 Effective Bundle Resolver（生效配置解析器）

- **版本向量**：`(harness, harness_version, model, profile/mode, sandbox, plugin_set_hash, asset_version_set_hash)`。
- 每个 session 解析出 `EffectiveBundle`，带 provenance（每一维来自哪个文件/字段/推断规则）与完整度标记；解析不出的维度标 unknown。
- **硬约束：每个 FrictionEvent 强制外键到当时的 EffectiveBundle**——"版本是维度不是功能"的工程落点，任何检测结果天然可按"什么变了"切片，不存在独立的回归检测模块。
- 输出 ECM（实际生效配置清单）：本次 session 生效的 profile/plugin/skill/rules/tools/policy、各项来源与配置层、覆盖与禁用关系、仅在 catalog 与真正进入上下文的区分、清单数据来源与完整度。Codex 的 TurnContext 与 dsh 的 `--dump-config`/插件树提供 Exact 输入；Claude Code 由文件规则 + 快照 + 轨迹证据近似。

### 4.5 Enrichers（补充器）

git 状态（commit、branch、dirty）、模型价格表（成本核算，随价格版本存档）、任务形状特征提取。均为纯派生，可整体重算。

### 4.6 Deterministic Quality Engine（确定性检测引擎）

**核心原语唯一：相对参照窗口的 first-seen / no-longer-seen。**

| 窗口类型 | 定义 | 服务场景 |
| --- | --- | --- |
| 滑动基线窗 | 最近 N 个相似 session | 持续检测：新报错类型、一直正常的工具链开始失败 |
| 变化点窗 | EnvironmentChanged 锚点前后 | "自 2.14 升级以来新出现了 X"（陈述变化，不判因果） |
| 修改锚点窗 | 用户某次 Change 前后 | 观察窗结算 |

Detector 分两类：

- **可目视验证类**：命令/工具明确失败、连续等价重试、失败后替换命令/库/路径、多轮错误循环、明确自我纠正、分支方案明确放弃、引用的路径/命令/API 不存在、资产间可形式化的冲突、**skill 显式调用后对应工具链持续异常或行为违背**、可观测的 offered/loaded 差异。局部因果，单条成立，UI 可大声呈现。
- **统计类**：摩擦率不对称、修改前后分布变化、context pressure 与资产体积关系。必须携带分母、任务构成、反例与置信区间，样本不足输出 unknown。

需要语义判断的命题（"这个 skill 本该触发""失败由这条规则造成""产出质量更差"）不得伪装成确定性事实，只能进入 inferred 或 AI 分析。

Detector 契约：`(id, version, required_fields, applicable_adapters, window_types)`。required_fields 对照适配器字段矩阵，缺字段自动降级或禁用。派生结果携带 detector version，引擎升级整体重算。

王牌 detector（invoked-then-violated）实现路径：skill 调用事件（CC 侧 Exact）→ 取调用点生效的 `AssetVersion` 内容 → 从 SKILL.md 提取可形式化要求（命令白/黑名单、必需步骤、路径约定——仅取可确定性对照的部分）→ 与调用点后的实际 tool_use 序列对照。语义性要求留给 AI 分析层。

排序原则写进代码：按**不对称与变化**排序，不按摩擦绝对量（重试与自我纠正是 agent 的正常工作方式）。

### 4.7 Comparison Engine（对比引擎）

- 分组维度：模型、harness、profile/mode、时间、资产版本、任务形状。
- 输出必含：构成、反例、样本量、缺失度；不默认生成"谁最好"总排名。
- 任务形状用透明结构特征（改动文件数与规模、语言/框架、工具类别、是否涉及构建/测试/网络/数据库/部署、session 长度与 subagent 数、粗粒度意图分类），明示为提高可比性的近似，不包装成对照实验。
- 基线三级：个人历史基线（本地）、团队项目基线（团队授权）、匿名群体参考区间（Reference Engine）。

### 4.8 Change Tracker & Observation Windows（修改追踪与观察窗）

- `Change`：快照器检测到资产哈希变化即自动创建（用户无需申报），可选关联 finding/suggestion。
- `ObservationWindow`：Change 后按任务形状匹配相似 session，累积到最小样本或超时后结算，输出 `improved / regressed / inconclusive / no-longer-observed` 及支撑数字。
- 用户 verdict（confirmed / false-positive / ignored / accepted）回流为 `UserFeedback`，参与 detector confidence 校准。

### 4.9 Findings、证据链与认识论状态

- Finding 卡片契约：标题（发生了什么）、状态（Observed/Derived/Inferred/AI Analysis）、范围（资产、版本、项目、模型、harness）、数字（分子/分母）、构成、证据（可展开至原始事件与配置来源）、反例、缺失（哪些关键字段不可观测）、解释（含替代解释）、建议（可选、不自动执行）、验证（修改后观察什么算改善）。
- confidence 不由 AI 填写，由确定因素计算：观测等级、required fields 完整度、detector 历史精度、样本量与反例、跨适配器一致性、用户反馈校准。
- 默认不显示综合"质量分"；若提供评分必须可分解、可解释，且与原始度量同屏。

### 4.10 AI Analysis Runtime

- 后端统一接口，三种实现：本地已有 agent / BYOK / 官方托管（经隐私网关，见 §5.7）。
- 输入：从 finding 构造的最小 evidence pack（结构化事实 + locator 摘录），不整段直灌 transcript。
- 输出契约：结构化 claims，逐条引用 evidence id；区分 evidence / interpretation / hypothesis / recommendation；必须输出反例与未知信息；无证据内容标 hypothesis。
- 不自动写入任何资产；保存 analyzer、模型、prompt、输入证据版本；可重跑、可比较、可拒绝。

### 4.11 Privacy Gateway（隐私网关）

任何数据离开本机的唯一通路。数据等级：

| 等级 | 离开本机的内容 | 用途 | 默认 |
| --- | --- | --- | --- |
| L0 | 无 | 完整本地使用 | 开启 |
| L1 | 匿名聚合度量、版本、任务形状、数据质量 | 群体参考 | 关闭，自愿加入 |
| L2 | 用户逐条选择且脱敏的事件/证据片段 | 托管 AI、支持 | 单次/项目授权 |
| L3 | 完整 trace 或团队数据 | 团队服务端协作 | 明确工作区授权 |
| Enterprise | 留在客户环境/VPC | 企业治理 | 合同配置 |

原则与机制：

- **字段 allowlist 优先**，不采用"全量建立后靠正则删除敏感字段"的黑名单脱敏。
- 路径、仓库名、prompt、代码、命令输出默认不属于 L1。
- 上传前 dry-run 预览；上传后可导出与删除；每个项目可见当前已授权的数据等级。
- public skill 经内容哈希或公开版本聚合；私人 skill 只上传结构特征或本地生成的类别。
- 所有本地导出（报告、CI 注释）同样经过网关，保证出口通路唯一。
- schema 每次升级触发重新隐私审查。

---

## 5. 官方后台服务设计

### 5.1 总则

- 后台 schema 与本地 schema 独立演进，通过 `SyncEnvelope` 协议保持兼容。
- 后台对客户端暴露统一 API；本地 UI 登录后合并两端结果，不存在独立的"云端控制台"产品。官方网站提供账户管理与已同步数据视图，不取代本地客户端对完整数据的访问。
- 账户不是使用产品的前置条件，是启用网络化能力的凭证。

### 5.2 Account & Device Service

注册、登录、会话与账号安全；用户、订阅、偏好；设备注册与授权（一个账户多设备）、撤销、客户端版本与最后同步状态。本地模式不依赖该服务。

### 5.3 Organization / Team / RBAC

- 实体：Organization（计费与企业边界）、Team（协作边界，可隶属 org）、Membership（用户 × 团队 × 角色 × 有效期）、RemoteProject（与一个或多个本地 workspace 的**用户确认**映射）。
- 角色：owner / admin / maintainer / member / viewer；邀请、退出、转移、审计。
- DataPolicy 为一等对象：项目允许上传的数据等级、保留期、成员可见性。团队管理员能设置策略，但**不能绕过本地客户端读取未授权的个人文件**；个人配置不因加入团队而自动公开；个人全局 skill 与团队规则冲突时，默认共享"存在个人级冲突"这一事实，不自动共享个人规则原文。

### 5.4 Sync Service（同步协议）

`SyncEnvelope` 结构要点：

```json
{
  "envelope_id": "幂等键（客户端生成）",
  "device_id": "...",
  "remote_project": "...",
  "object_type": "finding | aggregate | asset_metadata | selected_evidence | team_trace",
  "object_id": "...",
  "object_version": 7,
  "schema_version": "...",
  "detector_version": "...",
  "data_level": "L1 | L2 | L3",
  "policy_ref": "生效的 DataPolicy 版本",
  "payload": { }
}
```

- 幂等：服务端按 `envelope_id` 去重、按 `(object_id, object_version)` upsert；客户端断网续传，恢复后重放安全。
- 冲突：对象级单调版本；并发写入保留双版本并标记冲突，由产生对象的一端（通常是本地）裁决合并——服务端不做语义合并。
- 生命周期：用户退出团队、撤销设备或降低数据等级后，服务端执行对应的停止同步与删除策略，且删除可审计。

### 5.5 Aggregate Ingestion（聚合摄取）

- 只接收通过 schema 验证与隐私策略过滤的统计记录；**服务端二次防线：拒绝 payload 中意外出现的 prompt、代码、路径、secret 形态字段**（进入即失败，而非入库后清洗）。
- 保存客户端、适配器、detector、schema 版本，供 Reference Engine 分层。

### 5.6 Reference Engine（群体参考）

- cohort 键：`(agent, harness 版本段, model, 任务形状类, 资产类型/公开哈希, 观测等级)`。
- 最小 cohort 阈值（如 ≥20 独立设备）以下不发布，防反向识别。
- 输出**参考区间**而非单一均值；不发布"skill 出错概率"这类归因式指标，发布：可观测候选任务中的明确加载率、加载后摩擦事件率、重试/替换/绕行/未完成分布、建议采纳率、采纳后改善/恶化/样本不足比例、资产版本在不同 harness/model/profile 下的参考区间。
- 每个指标携带：cohort 定义、时间窗、样本量、分母、missingness、观测等级、置信区间、detector 版本。

### 5.7 Managed AI Analysis（托管分析）

只接收经隐私网关的 L2 evidence pack；支持团队私有提示与知识；保存分析模型与 prompt 版本；结果回到本地证据链呈现，遵守与本地 AI Runtime 相同的输出契约。

### 5.8 Subscription & Entitlement

- 套餐：个人 / 团队 / 企业；entitlement 覆盖托管 AI 额度、同步容量、团队成员数、保留期。
- 权限判断在服务端执行，客户端缓存 entitlement 并设离线宽限期（如 72h）；**本地免费能力永不因断网或订阅状态失效**。

### 5.9 后台技术选型

- Web 后台采用成熟框架实现账户/组织/订阅/审计等常规 SaaS 能力。
- PostgreSQL 承载账户、工作区、同步对象、聚合 finding 与 cohort；大规模事件分析出现瓶颈后引入 ClickHouse，不提前引入。
- 对象存储仅用于用户明确授权的报告与证据包。
- 企业部署：私有后台、VPC/内网、企业模型接入、集中策略、可选禁止任何外发。

---

## 6. 数据模型

### 6.1 本地核心 ER

```mermaid
erDiagram
    WORKSPACE ||--o{ ASSET : owns
    ASSET ||--o{ ASSET_VERSION : versions
    WORKSPACE ||--o{ SESSION : contains
    SESSION ||--o{ EVENT : records
    SESSION ||--|| EFFECTIVE_BUNDLE : runs_with
    EFFECTIVE_BUNDLE ||--o{ ENVIRONMENT_CHANGE : anchors
    ASSET_VERSION ||--o{ ASSET_EXPOSURE : exposed_as
    SESSION ||--o{ ASSET_EXPOSURE : observes
    EVENT ||--o{ FRICTION_EVENT : derives
    EFFECTIVE_BUNDLE ||--o{ FRICTION_EVENT : contextualizes
    FRICTION_EVENT }o--o{ FINDING : supports
    ASSET_VERSION }o--o{ FINDING : concerns
    FINDING ||--o{ SUGGESTION : proposes
    SUGGESTION ||--o{ CHANGE : produces
    CHANGE ||--o{ OUTCOME_WINDOW : observes
    FINDING ||--o{ USER_FEEDBACK : judged_by
```

关键实体语义：

| 实体 | 关键内容 |
| --- | --- |
| Workspace | 本地项目、仓库、个人环境 |
| Session | 来源、项目、模型、时间、状态、观测质量汇总 |
| Event | 规范化追加事件 + source locator |
| Asset / AssetVersion | skill、AGENTS.md、rule、workflow、hook、插件配置；内容哈希、scope、git、`[valid_from, valid_to)` |
| EffectiveBundle | 版本向量 + provenance + 完整度 |
| EnvironmentChange | 哪一维、从何变到何、时间（锚点） |
| AssetExposure | offered / loaded / injected / invoked / observed-use / unknown，各带观测等级 |
| FrictionEvent | 错误、重试、替换、放弃、自我纠正、冲突等派生事实；**强制关联 EffectiveBundle** |
| Finding | 对一组证据的可审计聚合 |
| Suggestion / Change / OutcomeWindow | 建议 → 用户实际修改 → 修改后观察结果 |
| UserFeedback | confirmed / false-positive / ignored / accepted + 原因 |

### 6.2 认识论状态与 confidence

六态枚举贯穿全库（见 §1.2）。confidence 由确定因素计算：观测等级、required fields 完整度、detector 历史精度、样本量与反例、跨适配器一致性、用户反馈校准；AI 不得自行填写。

### 6.3 服务端实体

| 实体 | 关键内容 |
| --- | --- |
| Account / Device | 身份、套餐、设备授权与同步状态 |
| Organization / Team / Membership | 计费边界、协作边界、角色与有效期 |
| RemoteProject | 与本地 workspace 的用户确认映射 |
| DataPolicy | 项目数据等级、保留期、可见性 |
| SyncEnvelope | 幂等、版本化同步包（见 §5.4） |
| SharedFinding | 团队可见 finding、统计与最小证据 |
| ReferenceContribution | 进入匿名 cohort 的去标识聚合记录 |

---

## 7. 存储设计

### 7.1 本地 SQLite 表族

| 表 | 说明 |
| --- | --- |
| `raw_files` | 源文件注册：路径、adapter、版本、大小、mtime、覆盖率、增量游标 |
| `sessions` / `events` | 会话与 canonical 事件（append-only，`payload_ref` 指回原文件） |
| `assets` / `asset_versions` | 资产与版本 |
| `effective_bundles` / `environment_changes` | 版本向量与锚点 |
| `friction_events` | 派生摩擦事实（强制外键 bundle，携带 detector id/version） |
| `findings` / `finding_evidence` | finding 与证据链（外键至 event/asset_version） |
| `suggestions` / `changes` / `observation_windows` | 优化闭环 |
| `user_feedback` | verdict 与校准输入 |
| `sync_outbox` | 待同步 envelope 队列（离线续传） |
| `fts_*` | FTS5：session 文本、finding、资产内容检索 |

原则：`events` 及上游只增不改；`friction_events`、`findings` 为可整体重建的派生层，携带 `detector_version` / `engine_schema_version`；无 ORM，手写 SQL + 编号迁移（向前不向后）；库文件位于 `~/.<product>/data.db`，权限 0600。

### 7.2 服务端存储

PostgreSQL（账户/团队/同步对象/聚合/cohort）+ 对象存储（授权证据包）；后台 schema 独立演进；ClickHouse 仅在事件分析达到瓶颈后引入。

---

## 8. 扩展架构

扩展点：`SourceAdapter`（新 harness/日志/OTel）、`AssetProvider`（新资产类型）、`EffectiveSetResolver`（作用域与覆盖解析）、`Detector`、`Enricher`、`AIAnalyzer`、`Exporter`。

执行模型：官方适配器与 detector 以**内置模块**交付；第三方扩展经受限子进程（stdio + JSON 契约）或 WASM 运行，声明所需字段、权限、网络与文件范围；每个插件输出保留 plugin id/version；提供样本数据测试，避免要求用户上传真实 transcript。

**不可由任何插件重定义**：canonical event identity、evidence provenance、认识论状态、隐私与上传策略、用户授权边界、finding 最小证据契约。

---

## 9. 安全设计

- **本地**：loopback 绑定 + Host/Origin 校验 + 本地 API token；数据库 0600；数据源只读；daemon 以普通用户权限运行，不要求提权。
- **出口**：隐私网关唯一通路；allowlist 优先；dry-run 预览；项目级与数据类型级授权；删除与撤回可审计。
- **服务端**：设备级授权与撤销；最小数据原则；聚合入口拒绝意外敏感字段；cohort 最小阈值；全链路审计；企业可完全私有部署并禁止外发。
- **供应链**：桌面壳与 daemon 二进制签名；更新清单签名校验；第三方插件默认沙箱。

---

## 10. 架构决策记录（ADR）

**ADR-1 单二进制 + SQLite，不做本地服务化。**单机数据量在 SQLite 舒适区内；部署复杂度是最大采纳摩擦。

**ADR-2 内核语言 Go；SQLite 驱动 `modernc.org/sqlite`（纯 Go）。**并发模型匹配负载、交叉编译 + embed 支撑单二进制交付；禁用 CGO 驱动以保住零依赖交叉编译。Rust 全栈为可行备选，切换不影响其余设计。

**ADR-3 桌面端 = Tauri v2 壳 + daemon sidecar；壳不含业务逻辑。**壳与内核经进程边界解耦，语言无需一致；壳层实际编写量以前端 JS/TS 为主。Wails 因默认绑定 UI 与 Go 进程、与"daemon 独立于界面"架构相悖而不选。

**ADR-4 自建 canonical schema；AgentsView 作为输入适配器而非事实模型。**其模型缺资产暴露与上下文来源两个核心维度；parser 成果经适配器复用（MIT）。

**ADR-5 第三方代码不进主进程。**内置模块 + stdio/WASM 外部插件；核心六项契约不可被插件重定义。

**ADR-6 版本是维度不是功能。**EffectiveBundle 强制外键 + EnvironmentChanged 锚点；UI 语言固定为"自变化点以来的新增现象"，禁止"版本 X 更差"。

**ADR-7 王牌 detector 为 invoked-then-violated。**证据链两端 Direct；"该触发未触发"仅在快照器/hook 提供 offered 数据后以 Derived/Inferred 等级出现。

**ADR-8 Hook 是观测升级开关，默认关闭。**纯被动读取下产品完整可用；hook 提供 Partial→Exact 跃迁。

**ADR-9 隐私网关为唯一出口，契约先于云端能力存在。**本地导出与云同步共用同一通路，接入后台不改数据路径。

**ADR-10 服务端不做语义合并。**同步冲突保留双版本，由产生对象的一端裁决；后台是协调者不是仲裁者。

---

## 附录 A · 适配器设计的实证依据（2026-08-17 调研）

1. **Claude Code transcript**（`~/.claude/projects/<encoded-path>/<session-id>.jsonl`）：每行含 `type/uuid/parentUuid/timestamp/sessionId/cwd/gitBranch/version`；assistant 条目含 `message.content`（text/thinking/tool_use 块）与 `message.usage`；tool_result 以同 id 关联。官方文档明确该格式为内部实现、随版本变化、直接解析可能在任意 release 失效 → fixture 回归与版本探测为必需工程。已知 bug：流式 output token 低估（issue #27361），成本统计需注记。
2. **Skill 机制（CC）**：候选集（name+description）注入系统提示，系统提示不写入 transcript → offered 不可从日志获得；显式调用经 Skill 工具作为 `tool_use` 块落盘（SkillKit `connectors/claude.ts` 依此解析），含稳定 `toolu_` id → invoked 为 Exact。
3. **Codex rollout**（`codex-rs/rollout/src/policy.rs`）：`Message/FunctionCall/FunctionCallOutput/Reasoning/TurnContext/SessionMeta/Compacted` 等持久化；**`AdditionalTools` 显式排除**（工具暴露集不落盘）；`SessionConfigured/HookStarted/McpStartupUpdate/Error(EventMsg)` 等标记 transient 不落盘。`TurnContextItem`（`protocol.rs:3021`）持久化 cwd、workspace_roots、approval_policy、sandbox_policy、permission_profile、model、effort、personality、collaboration_mode → ECM 的 Exact 原料。AGENTS.md 经 `agents_md.rs` 拼装为 user instructions 注入消息流，内容级可见。
4. **Codex skill 检测现状**：无原生 skill 事件；SkillKit 以正则 `skills/<name>/SKILL.md` 匹配 `exec_command` 参数 → Inferred，agent 换路径即漏检；本产品沿用该法并如实标注 Inferred。
5. **触发决策不可被动观测**：SkillKit 的 conflicts 功能采用主动探测（生成合成 prompt 实测），佐证触发环节无被动信号；本产品不做主动探测（避免改变用户环境行为），以快照 + hook 补 offered 侧。
