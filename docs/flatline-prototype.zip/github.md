repo: deepseek-ai/deepseek-harness
branch: main
path: packages/client/ui-trajectory

## Also read

- wesm/agentsview@main — README.md (session browser / dashboard / usage IA)
- crafter-station/skill-kit@main — README.md (context tax, exposure metrics)
- lobehub/lobe-icons@master — brand marks copied into `icons/` (MIT library; each mark remains its owner's trademark, used here to identify the product)

## Last sync

date: 2026-08-18T01:13:10Z
commit: 47f943859bef60e4160492346772ded9b24f765a

### Updated in this project

- Confirmed `actualDuration` (21 refs) reaches only `timelineMode` → `TrajectoryTimeline`; it never touches `TrajectoryTable`, so the Duration toggle changing only the Overview is source behaviour, not a bug.
- Rebuilt the asset detail on the RunScreen detail layout: full-width wrapping two-column split (main + 340px rail), every block a `SectionCard` (`elevated-card`) — the mixed `us-card` usage is gone (0 left). Funnel steps became plain stat columns inside one card instead of four nested cards.

- Confirmed from source that Turns/Calls do NOT drive the Overview: `TrajectoryTimeline.tsx:247` memoises `deriveTrajectoryTimeline(turns, mode)` on `[mode, turns]` only, and `timeline.ts` documents `turns` as the unfiltered layout — collapsing lives in `TrajectoryTable.tsx:1768`. Duration drives it via `timelineMode` (`TrajectoryView.tsx:284`), and Search dims non-matching spans through `searchMatchIndexes` (`:474` → `data-search-match='false'`, opacity 0.14). Implemented the search dimming, which was the one real gap.
- Added the asset source view: `Terminal` showing the selected AssetVersion's text, wired to the version timeline (picking v3 vs v4 swaps the body), plus the formalizable-rule extraction, the semantic-only requirements, and the CLAUDE.md/AGENTS.md conflict note.
- Fixed a layout regression where an earlier scripted edit swallowed the session two-pane wrapper; both panes now share top 205 / height 494.

- Checked `locales.ts` (14 keys: one view label + 13 toolbar strings) and confirmed the trajectory view ships NO help or hint copy — removed the invented "拖选聚焦 · 右键清除" line.
- Dropped the session-detail stat strip; its values moved into the ECM tab, where each one carries provenance and an observation level (13 dims, 11 parseable).

- Rebuilt the trajectory Overview against the real `TrajectoryTimeline.module.css`: 44px lane-label gutter + 50px plot grid, 8px spans at `lane × 14px` with 1px radius, per-kind colours (user / context / message / tool / error), TTFT gradient on message spans, 0.78 rest / 0.2 unfocused opacity, ±100vw selection scrim with 3px edge handles, 2px hover line, 1px turn boundaries, and 8px fixed spans in equal-duration mode.
- Turn headers now match `TrajectoryTurnHeader.module.css`: sticky 44px bar on ghost-active fill, title left, a 4×71px + 12px gap column lane (Input / Output / Think / Time) right, 8px trailing margin — ledger rows use the same lane so values line up.

- Copied real harness brand marks from lobe-icons into `icons/`: `claudecode.svg`, `deepseek.svg`, and `codex-light.svg` / `codex-dark.svg` (the source Codex mark is `currentColor`, so it was forked into two fixed-colour files for light and dark mode). They replace the letter monograms in the 28px `--muted` slot on the Sessions list, the sidebar data-source rows, and the Overview harness table.
- Earlier: read the real `ui-trajectory` package and rebuilt the session screen as a Trajectory view (ledger, 3-lane Overview with drag-to-focus, Duration/Turns/Calls/Search toolbar, inspector), with the seven verbatim kind tags System / User / Context / Compacted / Message / Tool / Sub.

## Sync history

- 2026-08-17T11:05:00Z — deepseek-harness @ `47f943859bef60e4160492346772ded9b24f765a`, trajectory view built.

## Screen map

| Screen | Built from |
| --- | --- |
| Session · 轨迹 (ledger + Overview + inspector) | deepseek-harness packages/client/ui-trajectory (README.md, TrajectoryToolbar.tsx, TrajectoryCell.tsx, timeline.ts, locales.ts) |
| Session · 对话 (transcript + friction axis + ECM) | uploads/agent-quality-platform-system-design.md §4.3–4.4 |
| Sessions / Findings / Assets lists | design doc §3.4; agentsview README; Unsloth Studio kit (TitleBar + catalog rows + SegmentedControl) |
| Finding detail | design doc §4.6, §4.9, ADR-7; Unsloth TrainScreen layout (tabs + SectionCard rail) |
| Asset detail (versions / funnel / context tax) | design doc §4.2; skill-kit README |
| Harness marks (sessions list, sidebar, overview) | lobehub/lobe-icons packages/static-svg/icons (claudecode-color, codex, deepseek-color) |
