/* @ds-bundle: {"format":4,"namespace":"DesignSystem_58676a","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"AvatarGroup","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CardHeader","sourcePath":"components/core/Card.jsx"},{"name":"CardTitle","sourcePath":"components/core/Card.jsx"},{"name":"CardDescription","sourcePath":"components/core/Card.jsx"},{"name":"CardContent","sourcePath":"components/core/Card.jsx"},{"name":"CardFooter","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Separator","sourcePath":"components/core/Separator.jsx"},{"name":"Skeleton","sourcePath":"components/core/Skeleton.jsx"},{"name":"Spinner","sourcePath":"components/core/Spinner.jsx"},{"name":"StatRow","sourcePath":"components/data/StatRow.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Empty","sourcePath":"components/feedback/Empty.jsx"},{"name":"InfoHint","sourcePath":"components/feedback/InfoHint.jsx"},{"name":"Progress","sourcePath":"components/feedback/Progress.jsx"},{"name":"Terminal","sourcePath":"components/feedback/Terminal.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"InputGroup","sourcePath":"components/forms/InputGroup.jsx"},{"name":"Label","sourcePath":"components/forms/Label.jsx"},{"name":"RadioGroup","sourcePath":"components/forms/RadioGroup.jsx"},{"name":"SegmentedControl","sourcePath":"components/forms/SegmentedControl.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Slider","sourcePath":"components/forms/Slider.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Toggle","sourcePath":"components/forms/Toggle.jsx"},{"name":"ToggleGroup","sourcePath":"components/forms/Toggle.jsx"},{"name":"Breadcrumb","sourcePath":"components/navigation/Breadcrumb.jsx"},{"name":"NavRow","sourcePath":"components/navigation/NavRow.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"Sidebar","sourcePath":"components/navigation/Sidebar.jsx"},{"name":"SidebarGroup","sourcePath":"components/navigation/Sidebar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Accordion","sourcePath":"components/overlay/Accordion.jsx"},{"name":"Dialog","sourcePath":"components/overlay/Dialog.jsx"},{"name":"Menu","sourcePath":"components/overlay/Menu.jsx"},{"name":"Popover","sourcePath":"components/overlay/Popover.jsx"},{"name":"Composer","sourcePath":"components/product/Composer.jsx"},{"name":"ComposerPill","sourcePath":"components/product/Composer.jsx"},{"name":"ModelRow","sourcePath":"components/product/ModelRow.jsx"},{"name":"SectionCard","sourcePath":"components/product/SectionCard.jsx"},{"name":"Wordmark","sourcePath":"components/product/Wordmark.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"9e7b6056ea25","components/core/Badge.jsx":"b4f09ab71f49","components/core/Button.jsx":"d957f7b3aea5","components/core/Card.jsx":"f4aae4d8b3fc","components/core/Icon.jsx":"27cce9cc2dc7","components/core/Separator.jsx":"b8c17120d21f","components/core/Skeleton.jsx":"acd3062305cb","components/core/Spinner.jsx":"8b0eb30dbccf","components/data/StatRow.jsx":"4deec6003b46","components/data/Table.jsx":"81268aa5074b","components/feedback/Alert.jsx":"2231acf4c213","components/feedback/Empty.jsx":"d15b3f168ed1","components/feedback/InfoHint.jsx":"bb58840056bb","components/feedback/Progress.jsx":"64b3788fee97","components/feedback/Terminal.jsx":"b9f2ae9bd396","components/feedback/Toast.jsx":"e2d60c28ad6a","components/feedback/Tooltip.jsx":"7dc76f4947ca","components/forms/Checkbox.jsx":"38a07bba13db","components/forms/Field.jsx":"6c600653dab6","components/forms/Input.jsx":"52f35fae9018","components/forms/InputGroup.jsx":"9b20504d40fe","components/forms/Label.jsx":"0b9595ad972a","components/forms/RadioGroup.jsx":"3e6297edb039","components/forms/SegmentedControl.jsx":"444a6f7c72e6","components/forms/Select.jsx":"6fba3171bdbe","components/forms/Slider.jsx":"6367b60f6840","components/forms/Switch.jsx":"18fce567c08d","components/forms/Textarea.jsx":"826acb9567fc","components/forms/Toggle.jsx":"5e77a70c51c1","components/navigation/Breadcrumb.jsx":"42c8ea73fcfc","components/navigation/NavRow.jsx":"097e58174716","components/navigation/Pagination.jsx":"9b124411f0bd","components/navigation/Sidebar.jsx":"9d00bd5b3a79","components/navigation/Tabs.jsx":"38d9c7e3bea8","components/overlay/Accordion.jsx":"252939b32d68","components/overlay/Dialog.jsx":"3f521a06e64f","components/overlay/Menu.jsx":"a04ad7421f9e","components/overlay/Popover.jsx":"85c9e7640052","components/product/Composer.jsx":"e4741d4c4909","components/product/ModelRow.jsx":"07770c8f2379","components/product/SectionCard.jsx":"4b0613ba0346","components/product/Wordmark.jsx":"38da7f488027","ui_kits/studio/ChatScreen.jsx":"372d2b7dd6eb","ui_kits/studio/HubScreen.jsx":"4009bd82151b","ui_kits/studio/LoginScreen.jsx":"860bc620e509","ui_kits/studio/RunScreen.jsx":"9d82b4202143","ui_kits/studio/SettingsScreen.jsx":"90f7e654c0f5","ui_kits/studio/Shell.jsx":"808b64dd8262","ui_kits/studio/TrainScreen.jsx":"b8e14342f6d3"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystem_58676a = window.DesignSystem_58676a || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Avatar({
  size = "default",
  src,
  alt = "",
  fallback,
  className = "",
  children,
  ...rest
}) {
  const [failed, setFailed] = React.useState(false);
  const showImage = src && !failed;
  return /*#__PURE__*/React.createElement("span", _extends({
    "data-slot": "avatar",
    "data-size": size,
    className: `us-avatar ${className}`
  }, rest), showImage ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    onError: () => setFailed(true)
  }) : /*#__PURE__*/React.createElement("span", {
    className: "us-avatar-fallback"
  }, fallback ?? children));
}
function AvatarGroup({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "avatar-group",
    className: `us-avatar-group ${className}`
  }, rest), children);
}
Object.assign(__ds_scope, { Avatar, AvatarGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Badge({
  variant = "default",
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    "data-slot": "badge",
    "data-variant": variant,
    className: `us-badge ${className}`
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = "default",
  size = "default",
  className = "",
  type = "button",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    "data-slot": "button",
    "data-variant": variant,
    "data-size": size,
    className: `us-btn ${className}`
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  size = "default",
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card",
    "data-size": size,
    className: `us-card ${className}`
  }, rest), children);
}
function CardHeader({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-header",
    className: `us-card-header ${className}`
  }, rest), children);
}
function CardTitle({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-title",
    className: `us-card-title ${className}`
  }, rest), children);
}
function CardDescription({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-description",
    className: `us-card-description ${className}`
  }, rest), children);
}
function CardContent({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-content",
    className: `us-card-content ${className}`
  }, rest), children);
}
function CardFooter({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-footer",
    className: `us-card-footer ${className}`
  }, rest), children);
}
Object.assign(__ds_scope, { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Unsloth Studio uses Hugeicons (stroke icons, strokeWidth 2, 16px default) as
   its primary set, with lucide-react for a few glyphs. Hugeicons ships as JS
   icon data with no CDN sprite, so this wrapper renders Lucide names — the
   closest stroke-weight match — and the host page loads Lucide's UMD build.
   See readme.md > ICONOGRAPHY for the substitution note. */
function Icon({
  name,
  size = 16,
  strokeWidth = 2,
  color = "currentColor",
  style,
  ...rest
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const node = ref.current;
    if (!node || !window.lucide) return;
    node.innerHTML = "";
    const el = document.createElement("i");
    el.setAttribute("data-lucide", name);
    node.appendChild(el);
    window.lucide.createIcons({
      nameAttr: "data-lucide",
      attrs: {
        width: size,
        height: size,
        "stroke-width": strokeWidth,
        stroke: color
      },
      root: node
    });
  }, [name, size, strokeWidth, color]);
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    "aria-hidden": "true",
    style: {
      display: "inline-flex",
      flexShrink: 0,
      width: size,
      height: size,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Separator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Separator({
  orientation = "horizontal",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "separator",
    "data-slot": "separator",
    "data-orientation": orientation,
    className: `us-sep ${className}`
  }, rest));
}
Object.assign(__ds_scope, { Separator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Separator.jsx", error: String((e && e.message) || e) }); }

// components/core/Skeleton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Skeleton({
  className = "",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "skeleton",
    className: `us-skeleton ${className}`,
    style: style
  }, rest));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/core/Spinner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Spinner({
  size = 16,
  label = "Loading",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("svg", _extends({
    role: "status",
    "aria-label": label,
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    className: `us-spinner ${className}`
  }, rest), /*#__PURE__*/React.createElement("path", {
    d: "M21 12a9 9 0 1 1-6.219-8.56"
  }));
}
Object.assign(__ds_scope, { Spinner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Spinner.jsx", error: String((e && e.message) || e) }); }

// components/data/StatRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatRow({
  items = [],
  className = "",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    style: {
      display: "flex",
      flexWrap: "wrap",
      alignItems: "center",
      gap: "4px 20px",
      fontSize: "var(--text-ui-13)",
      ...style
    }
  }, rest), items.map((item, index) => /*#__PURE__*/React.createElement("span", {
    key: index,
    style: {
      display: "inline-flex",
      alignItems: "baseline",
      gap: 6,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--panel-surface-fg-muted)"
    }
  }, item.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500,
      fontVariantNumeric: "tabular-nums",
      color: item.tone === "muted" ? "var(--panel-surface-fg-muted)" : "var(--foreground)"
    }
  }, item.value))));
}
Object.assign(__ds_scope, { StatRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatRow.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Table({
  columns = [],
  rows = [],
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "us-table-wrap"
  }, /*#__PURE__*/React.createElement("table", _extends({
    "data-slot": "table",
    className: `us-table ${className}`
  }, rest), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(column => /*#__PURE__*/React.createElement("th", {
    key: column.key,
    style: {
      textAlign: column.align ?? "left",
      width: column.width
    }
  }, column.header)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((row, index) => /*#__PURE__*/React.createElement("tr", {
    key: row.id ?? index
  }, columns.map(column => /*#__PURE__*/React.createElement("td", {
    key: column.key,
    style: {
      textAlign: column.align ?? "left"
    }
  }, row[column.key])))))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Alert({
  variant = "default",
  icon,
  title,
  description,
  action,
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    "data-slot": "alert",
    "data-variant": variant,
    "data-has-icon": Boolean(icon),
    className: `us-alert ${className}`
  }, rest), icon, title ? /*#__PURE__*/React.createElement("div", {
    className: "us-alert-title"
  }, title) : null, description ? /*#__PURE__*/React.createElement("div", {
    className: "us-alert-description"
  }, description) : null, children, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 10,
      right: 12
    }
  }, action) : null);
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Empty.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Empty({
  media,
  title,
  description,
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "empty",
    className: `us-empty ${className}`
  }, rest), media ? /*#__PURE__*/React.createElement("div", {
    className: "us-empty-media",
    "data-variant": "icon"
  }, media) : null, title ? /*#__PURE__*/React.createElement("div", {
    className: "us-empty-title"
  }, title) : null, description ? /*#__PURE__*/React.createElement("div", {
    className: "us-empty-description"
  }, description) : null, children);
}
Object.assign(__ds_scope, { Empty });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Empty.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Progress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Progress({
  value = 0,
  indeterminate = false,
  className = "",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "progressbar",
    "aria-valuenow": indeterminate ? undefined : value,
    "aria-valuemin": 0,
    "aria-valuemax": 100,
    "data-slot": "progress",
    "data-indeterminate": indeterminate,
    className: `us-progress ${className}`,
    style: style
  }, rest), /*#__PURE__*/React.createElement("div", {
    "data-slot": "progress-indicator",
    className: "us-progress-indicator",
    style: indeterminate ? undefined : {
      width: "100%",
      transform: `translateX(-${100 - value}%)`
    }
  }));
}
Object.assign(__ds_scope, { Progress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Progress.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Terminal.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Terminal({
  lines = [],
  className = "",
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "terminal",
    className: `us-terminal ${className}`,
    style: style
  }, rest), children ?? lines.map((line, index) => {
    const text = typeof line === "string" ? line : line.text;
    const tone = typeof line === "string" ? "default" : line.tone ?? "default";
    const color = tone === "muted" ? "var(--muted-foreground)" : tone === "success" ? "var(--verified)" : tone === "warn" ? "var(--bypass)" : tone === "error" ? "var(--destructive)" : "inherit";
    return /*#__PURE__*/React.createElement("div", {
      key: index,
      className: "us-terminal-line",
      style: {
        color
      }
    }, text);
  }));
}
Object.assign(__ds_scope, { Terminal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Terminal.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Toast({
  title,
  description,
  icon,
  action,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    className: `us-toast ${className}`
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      flexShrink: 0,
      marginTop: 1
    }
  }, icon) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2,
      minWidth: 0,
      flex: 1
    }
  }, title ? /*#__PURE__*/React.createElement("span", {
    className: "us-toast-title"
  }, title) : null, description ? /*#__PURE__*/React.createElement("span", {
    className: "us-toast-description"
  }, description) : null), action);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  label,
  side = "top",
  variant = "default",
  children,
  className = "",
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const offset = 6;
  const position = side === "top" ? {
    bottom: `calc(100% + ${offset}px)`,
    left: "50%",
    transform: "translateX(-50%)"
  } : side === "bottom" ? {
    top: `calc(100% + ${offset}px)`,
    left: "50%",
    transform: "translateX(-50%)"
  } : side === "left" ? {
    right: `calc(100% + ${offset}px)`,
    top: "50%",
    transform: "translateY(-50%)"
  } : {
    left: `calc(100% + ${offset}px)`,
    top: "50%",
    transform: "translateY(-50%)"
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      position: "relative",
      display: "inline-flex"
    },
    onPointerEnter: () => setOpen(true),
    onPointerLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, rest), children, open ? /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    "data-slot": "tooltip-content",
    className: variant === "default" ? "tooltip-compact" : "us-popover",
    style: {
      position: "absolute",
      zIndex: 999,
      width: "max-content",
      maxWidth: "20rem",
      pointerEvents: "none",
      whiteSpace: variant === "default" ? "nowrap" : undefined,
      borderRadius: variant === "default" ? 9999 : undefined,
      ...position
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/InfoHint.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function InfoHint({
  label,
  side = "top",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Tooltip, {
    label: label,
    side: side
  }, /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": "More information",
    className: `us-info-hint ${className}`
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "10"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 16v-4M12 8h.01"
  }))));
}
Object.assign(__ds_scope, { InfoHint });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/InfoHint.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked,
  defaultChecked = false,
  onCheckedChange,
  disabled,
  className = "",
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultChecked);
  const isChecked = checked ?? internal;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "checkbox",
    "aria-checked": isChecked,
    disabled: disabled,
    "data-slot": "checkbox",
    "data-state": isChecked ? "checked" : "unchecked",
    className: `us-checkbox ${className}`,
    onClick: () => {
      const next = !isChecked;
      if (checked === undefined) setInternal(next);
      onCheckedChange?.(next);
    }
  }, rest), isChecked ? /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  })) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  className = "",
  type = "text",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    "data-slot": "input",
    className: `us-input ${className}`
  }, rest));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/InputGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function InputGroup({
  leading,
  trailing,
  className = "",
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "input-group",
    className: className,
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center",
      width: "100%",
      minWidth: 0,
      ...style
    }
  }, rest), leading ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 12,
      display: "inline-flex",
      color: "var(--muted-foreground)",
      pointerEvents: "none"
    }
  }, leading) : null, children, trailing ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 8,
      display: "inline-flex",
      alignItems: "center",
      gap: 4
    }
  }, trailing) : null);
}
Object.assign(__ds_scope, { InputGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/InputGroup.jsx", error: String((e && e.message) || e) }); }

// components/forms/Label.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Label({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    "data-slot": "label",
    className: `us-label ${className}`
  }, rest), children);
}
Object.assign(__ds_scope, { Label });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Label.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Field({
  label,
  hint,
  htmlFor,
  orientation = "vertical",
  children,
  className = "",
  ...rest
}) {
  const horizontal = orientation === "horizontal";
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "field",
    className: className,
    style: {
      display: "flex",
      flexDirection: horizontal ? "row" : "column",
      alignItems: horizontal ? "center" : "stretch",
      justifyContent: horizontal ? "space-between" : undefined,
      gap: horizontal ? 16 : 8
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      minWidth: 0
    }
  }, label ? /*#__PURE__*/React.createElement(__ds_scope.Label, {
    htmlFor: htmlFor
  }, label) : null, hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-12p5)",
      color: "var(--muted-foreground)",
      lineHeight: 1.45
    }
  }, hint) : null), children);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/RadioGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function RadioGroup({
  value,
  defaultValue,
  onValueChange,
  options = [],
  name,
  className = "",
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue);
  const current = value ?? internal;
  const groupName = React.useId();
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "radiogroup",
    "data-slot": "radio-group",
    className: className,
    style: {
      display: "grid",
      gap: 12,
      width: "100%"
    }
  }, rest), options.map(option => {
    const active = option.value === current;
    return /*#__PURE__*/React.createElement("label", {
      key: option.value,
      style: {
        display: "flex",
        alignItems: "flex-start",
        gap: 10,
        cursor: option.disabled ? "not-allowed" : "pointer",
        opacity: option.disabled ? 0.5 : 1
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "radio",
      name: name ?? groupName,
      value: option.value,
      checked: active,
      disabled: option.disabled,
      onChange: () => {
        if (value === undefined) setInternal(option.value);
        onValueChange?.(option.value);
      },
      style: {
        position: "absolute",
        opacity: 0,
        pointerEvents: "none",
        width: 1,
        height: 1
      }
    }), /*#__PURE__*/React.createElement("span", {
      "data-slot": "radio-group-item",
      "data-state": active ? "checked" : "unchecked",
      className: "us-radio",
      style: {
        marginTop: 2
      }
    }, active ? /*#__PURE__*/React.createElement("span", {
      className: "us-radio-dot"
    }) : null), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 2,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "var(--text-sm)",
        fontWeight: 500,
        lineHeight: 1.3
      }
    }, option.label), option.hint ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "var(--text-ui-12p5)",
        color: "var(--muted-foreground)",
        lineHeight: 1.45
      }
    }, option.hint) : null));
  }));
}
Object.assign(__ds_scope, { RadioGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RadioGroup.jsx", error: String((e && e.message) || e) }); }

// components/forms/SegmentedControl.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SegmentedControl({
  value,
  defaultValue,
  onValueChange,
  options = [],
  size = "default",
  ariaLabel,
  className = "",
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? options[0]?.value);
  const current = value ?? internal;
  const activeIndex = Math.max(0, options.findIndex(o => o.value === current));
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "radiogroup",
    "aria-label": ariaLabel,
    "data-size": size,
    className: `us-segmented hub-tab-toggle ${className}`,
    style: style
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    className: "us-segmented-pill hub-tab-toggle-pill",
    style: {
      width: `${100 / options.length}%`,
      transform: `translateX(${activeIndex * 100}%)`
    }
  }), options.map(option => /*#__PURE__*/React.createElement("button", {
    key: option.value,
    type: "button",
    role: "radio",
    "aria-checked": option.value === current,
    disabled: option.disabled,
    "data-active": option.value === current,
    className: "us-segmented-item",
    onClick: () => {
      if (value === undefined) setInternal(option.value);
      onValueChange?.(option.value);
    }
  }, option.label)));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  value,
  defaultValue,
  onValueChange,
  options = [],
  placeholder = "Select...",
  disabled,
  className = "",
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue);
  const [open, setOpen] = React.useState(false);
  const current = value ?? internal;
  const selected = options.find(o => o.value === current);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const close = event => {
      if (!ref.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [open]);
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: ref,
    className: className,
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    "aria-haspopup": "listbox",
    "aria-expanded": open,
    "data-slot": "select-trigger",
    "data-placeholder": !selected,
    className: "us-select-trigger",
    style: {
      width: "100%"
    },
    onClick: () => setOpen(v => !v)
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, selected ? selected.label : placeholder), /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    style: {
      flexShrink: 0,
      opacity: 0.6
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "m6 9 6 6 6-6"
  }))), open ? /*#__PURE__*/React.createElement("div", {
    role: "listbox",
    "data-slot": "select-content",
    className: "us-select-content",
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      left: 0,
      minWidth: "100%",
      zIndex: 50
    }
  }, options.map(option => /*#__PURE__*/React.createElement("button", {
    key: option.value,
    type: "button",
    role: "option",
    "aria-selected": option.value === current,
    className: "us-select-item",
    onClick: () => {
      if (value === undefined) setInternal(option.value);
      onValueChange?.(option.value);
      setOpen(false);
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, option.label), option.value === current ? /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  })) : null))) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Slider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Slider({
  value,
  defaultValue = 50,
  onValueChange,
  min = 0,
  max = 100,
  step = 1,
  disabled,
  className = "",
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue);
  const current = value ?? internal;
  const percent = max === min ? 0 : (current - min) / (max - min) * 100;
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "slider",
    className: `us-slider ${className}`,
    style: {
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "us-slider-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "us-slider-fill",
    style: {
      width: `calc(${percent}% + ${8 - percent / 50 * 8}px)`,
      borderRadius: percent >= 100 ? "var(--radius-4xl)" : undefined
    }
  })), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: min,
    max: max,
    step: step,
    value: current,
    disabled: disabled,
    onChange: event => {
      const next = Number(event.target.value);
      if (value === undefined) setInternal(next);
      onValueChange?.(next);
    },
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      opacity: 0,
      cursor: "pointer",
      margin: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    "data-slot": "slider-thumb",
    className: "us-slider-thumb",
    style: {
      position: "absolute",
      left: `${percent}%`
    }
  }));
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Slider.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked,
  defaultChecked = false,
  onCheckedChange,
  size = "default",
  disabled,
  className = "",
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultChecked);
  const isChecked = checked ?? internal;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "switch",
    "aria-checked": isChecked,
    disabled: disabled,
    "data-slot": "switch",
    "data-size": size,
    "data-state": isChecked ? "checked" : "unchecked",
    className: `us-switch ${className}`,
    onClick: () => {
      const next = !isChecked;
      if (checked === undefined) setInternal(next);
      onCheckedChange?.(next);
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "data-slot": "switch-thumb",
    className: "us-switch-thumb"
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("textarea", _extends({
    "data-slot": "textarea",
    className: `us-textarea ${className}`
  }, rest));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/forms/Toggle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Toggle({
  pressed,
  defaultPressed = false,
  onPressedChange,
  variant = "default",
  size = "default",
  disabled,
  className = "",
  children,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultPressed);
  const isPressed = pressed ?? internal;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-pressed": isPressed,
    disabled: disabled,
    "data-slot": "toggle",
    "data-variant": variant,
    "data-size": size,
    className: `us-toggle ${className}`,
    onClick: () => {
      const next = !isPressed;
      if (pressed === undefined) setInternal(next);
      onPressedChange?.(next);
    }
  }, rest), children);
}
function ToggleGroup({
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `us-toggle-group ${className}`
  }, rest), children);
}
Object.assign(__ds_scope, { Toggle, ToggleGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Toggle.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumb.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Breadcrumb({
  items = [],
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    "aria-label": "Breadcrumb",
    className: `us-breadcrumb ${className}`
  }, rest), items.map((item, index) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: index
  }, index > 0 ? /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    style: {
      opacity: 0.5
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "m9 18 6-6-6-6"
  })) : null, item.href ? /*#__PURE__*/React.createElement("a", {
    href: item.href
  }, item.label) : /*#__PURE__*/React.createElement("span", {
    "aria-current": "page"
  }, item.label))));
}
Object.assign(__ds_scope, { Breadcrumb });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumb.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function NavRow({
  icon,
  label,
  active = false,
  badge,
  trailing,
  as = "button",
  className = "",
  ...rest
}) {
  const Comp = as;
  return /*#__PURE__*/React.createElement(Comp, _extends({
    "data-slot": "nav-row",
    "data-active": active,
    className: `us-nav-row ${className}`
  }, as === "button" ? {
    type: "button"
  } : null, rest), icon, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, label), badge, trailing);
}
Object.assign(__ds_scope, { NavRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavRow.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Pagination({
  page = 1,
  pageCount = 1,
  onPageChange,
  className = "",
  ...rest
}) {
  const go = next => onPageChange?.(Math.min(pageCount, Math.max(1, next)));
  const pages = [];
  for (let i = 1; i <= pageCount; i += 1) pages.push(i);
  return /*#__PURE__*/React.createElement("nav", _extends({
    "aria-label": "Pagination",
    className: `us-pagination ${className}`
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "ghost",
    size: "icon-sm",
    "aria-label": "Previous page",
    disabled: page <= 1,
    onClick: () => go(page - 1)
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "m15 18-6-6 6-6"
  }))), pages.map(p => /*#__PURE__*/React.createElement(__ds_scope.Button, {
    key: p,
    variant: p === page ? "secondary" : "ghost",
    size: "icon-sm",
    "aria-current": p === page ? "page" : undefined,
    onClick: () => go(p)
  }, p)), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "ghost",
    size: "icon-sm",
    "aria-label": "Next page",
    disabled: page >= pageCount,
    onClick: () => go(page + 1)
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "m9 18 6-6-6-6"
  }))));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Sidebar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Sidebar({
  header,
  footer,
  className = "",
  style,
  children,
  ...rest
}) {
  const scrollRef = React.useRef(null);
  const [scrolled, setScrolled] = React.useState(false);
  return /*#__PURE__*/React.createElement("aside", _extends({
    "data-slot": "sidebar",
    className: `us-sidebar ${className}`,
    style: style
  }, rest), header ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      padding: "12px 8px 8px"
    }
  }, header) : null, /*#__PURE__*/React.createElement("div", {
    ref: scrollRef,
    className: `sidebar-scroll-fade hover-scrollbar${scrolled ? " is-scrolled" : ""}`,
    onScroll: event => {
      const next = event.currentTarget.scrollTop > 2;
      if (next !== scrolled) setScrolled(next);
    },
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "0 8px"
    }
  }, children, /*#__PURE__*/React.createElement("div", {
    className: "sidebar-bottom-fade"
  })), footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 8
    }
  }, footer) : null);
}
function SidebarGroup({
  label,
  className = "",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className
  }, rest), label ? /*#__PURE__*/React.createElement("div", {
    className: "us-sidebar-group-label"
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, children));
}
Object.assign(__ds_scope, { Sidebar, SidebarGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Sidebar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onValueChange,
  variant = "default",
  className = "",
  children,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? tabs[0]?.value);
  const current = value ?? internal;
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "tabs",
    className: `us-tabs ${className}`
  }, rest), /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    "data-slot": "tabs-list",
    "data-variant": variant,
    className: "us-tabs-list"
  }, tabs.map(tab => {
    const active = tab.value === current;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.value,
      type: "button",
      role: "tab",
      "aria-selected": active,
      "data-active": active,
      disabled: tab.disabled,
      className: "us-tabs-trigger",
      onClick: () => {
        if (value === undefined) setInternal(tab.value);
        onValueChange?.(tab.value);
      }
    }, active ? /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      className: "us-tabs-indicator"
    }) : null, /*#__PURE__*/React.createElement("span", {
      style: {
        position: "relative",
        zIndex: 1,
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, tab.label));
  })), children ? /*#__PURE__*/React.createElement("div", {
    className: "us-tabs-content"
  }, children) : null);
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Accordion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Accordion({
  items = [],
  defaultOpen = [],
  className = "",
  ...rest
}) {
  const [open, setOpen] = React.useState(() => new Set(defaultOpen));
  const toggle = value => setOpen(prev => {
    const next = new Set(prev);
    if (next.has(value)) next.delete(value);else next.add(value);
    return next;
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "accordion",
    className: className
  }, rest), items.map(item => {
    const isOpen = open.has(item.value);
    return /*#__PURE__*/React.createElement("div", {
      key: item.value,
      className: "us-accordion-item"
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      className: "us-accordion-trigger",
      "data-open": isOpen,
      "aria-expanded": isOpen,
      onClick: () => toggle(item.value)
    }, /*#__PURE__*/React.createElement("span", null, item.title), /*#__PURE__*/React.createElement("svg", {
      className: "us-accordion-chevron",
      width: "16",
      height: "16",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("path", {
      d: "m6 9 6 6 6-6"
    }))), isOpen ? /*#__PURE__*/React.createElement("div", {
      className: "us-accordion-content"
    }, item.content) : null);
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Dialog({
  open = true,
  onClose,
  title,
  description,
  footer,
  className = "",
  children,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24,
      zIndex: 100
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "us-dialog-overlay",
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    "data-slot": "dialog",
    className: `us-dialog ${className}`
  }, rest), title ? /*#__PURE__*/React.createElement("h2", {
    "data-slot": "dialog-title",
    className: "us-dialog-title"
  }, title) : null, description ? /*#__PURE__*/React.createElement("p", {
    className: "us-dialog-description"
  }, description) : null, children, footer ? /*#__PURE__*/React.createElement("div", {
    className: "us-dialog-footer"
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Menu.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Menu({
  items = [],
  trigger,
  align = "start",
  className = "",
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const close = event => {
      if (!ref.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [open]);
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    className: className,
    style: {
      position: "relative",
      display: "inline-flex"
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => setOpen(v => !v),
    style: {
      display: "inline-flex"
    }
  }, trigger), open ? /*#__PURE__*/React.createElement("div", {
    role: "menu",
    className: "us-menu app-user-menu",
    style: {
      position: "absolute",
      top: "calc(100% + 6px)",
      zIndex: 60,
      ...(align === "end" ? {
        right: 0
      } : {
        left: 0
      })
    }
  }, items.map((item, index) => item.type === "separator" ? /*#__PURE__*/React.createElement("div", {
    key: index,
    className: "us-sep",
    "data-orientation": "horizontal",
    style: {
      margin: "4px 0"
    }
  }) : item.type === "label" ? /*#__PURE__*/React.createElement("div", {
    key: index,
    className: "us-menu-label"
  }, item.label) : /*#__PURE__*/React.createElement("button", {
    key: index,
    type: "button",
    role: "menuitem",
    className: "us-menu-item",
    "data-variant": item.variant ?? "default",
    onClick: () => {
      item.onSelect?.();
      setOpen(false);
    }
  }, item.icon, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, item.label), item.shortcut ? /*#__PURE__*/React.createElement("span", {
    className: "us-menu-shortcut"
  }, item.shortcut) : null))) : null);
}
Object.assign(__ds_scope, { Menu });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Menu.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Popover.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Popover({
  content,
  side = "bottom",
  align = "start",
  className = "",
  children,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const close = event => {
      if (!ref.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [open]);
  const pos = side === "top" ? {
    bottom: "calc(100% + 6px)"
  } : {
    top: "calc(100% + 6px)"
  };
  const alignStyle = align === "end" ? {
    right: 0
  } : align === "center" ? {
    left: "50%",
    transform: "translateX(-50%)"
  } : {
    left: 0
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    className: className,
    style: {
      position: "relative",
      display: "inline-flex"
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => setOpen(v => !v),
    style: {
      display: "inline-flex"
    }
  }, children), open ? /*#__PURE__*/React.createElement("div", {
    "data-slot": "popover-content",
    className: "us-popover",
    style: {
      position: "absolute",
      zIndex: 60,
      ...pos,
      ...alignStyle
    }
  }, content) : null);
}
Object.assign(__ds_scope, { Popover });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Popover.jsx", error: String((e && e.message) || e) }); }

// components/product/Composer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Composer({
  placeholder = "Ask anything",
  pills,
  actions,
  value,
  onValueChange,
  className = "",
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState("");
  const text = value ?? internal;
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `chat-composer-surface ${className}`,
    style: style
  }, rest), /*#__PURE__*/React.createElement("textarea", {
    rows: 1,
    placeholder: placeholder,
    value: text,
    onChange: event => {
      if (value === undefined) setInternal(event.target.value);
      onValueChange?.(event.target.value);
    },
    className: "unsloth-composer-input",
    style: {
      width: "100%",
      resize: "none",
      border: 0,
      background: "transparent",
      padding: "8px 14px 4px",
      fontFamily: "inherit",
      fontSize: "var(--text-ui-15p5)",
      lineHeight: 1.5,
      color: "var(--foreground)",
      outline: "none",
      minHeight: 44,
      maxHeight: 200
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 2,
      padding: "2px 4px 6px"
    }
  }, pills, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), actions));
}
function ComposerPill({
  icon,
  label,
  active = false,
  variant = "default",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "data-active": active,
    "data-variant": variant,
    className: `composer-pill-btn ${className}`
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      width: 16,
      justifyContent: "center"
    }
  }, icon) : null, label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Composer, ComposerPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/Composer.jsx", error: String((e && e.message) || e) }); }

// components/product/ModelRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ModelRow({
  logo,
  name,
  owner,
  meta,
  tags = [],
  size,
  verified = false,
  selected = false,
  action,
  className = "",
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "model-row",
    "data-selected": selected,
    className: className,
    onPointerEnter: () => setHover(true),
    onPointerLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "10px 12px",
      borderRadius: "var(--radius-md)",
      background: selected ? "var(--accent)" : hover ? "var(--panel-surface-hover)" : "transparent",
      transition: "background-color 160ms ease",
      cursor: "pointer",
      ...style
    }
  }, rest), logo ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 28,
      height: 28,
      flexShrink: 0,
      borderRadius: 8,
      background: "var(--muted)",
      overflow: "hidden"
    }
  }, logo) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2,
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-13p5)",
      fontWeight: 500,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, name), verified ? /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--verified)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flexShrink: 0
    },
    "aria-label": "Verified"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  })) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: "var(--text-ui-11p5)",
      color: "var(--panel-surface-fg-muted)",
      minWidth: 0
    }
  }, owner ? /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, owner) : null, meta ? /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, meta) : null)), tags.map(tag => /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    key: String(tag.label ?? tag),
    variant: tag.variant ?? "outline"
  }, tag.label ?? tag)), size ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-12)",
      color: "var(--panel-surface-fg-muted)",
      fontVariantNumeric: "tabular-nums",
      flexShrink: 0
    }
  }, size) : null, action);
}
Object.assign(__ds_scope, { ModelRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/ModelRow.jsx", error: String((e && e.message) || e) }); }

// components/product/SectionCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SectionCard({
  title,
  description,
  action,
  footer,
  className = "",
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({
    className: `elevated-card ${className}`,
    style: {
      padding: 20,
      ...style
    }
  }, rest), title || action ? /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 16,
      marginBottom: description ? 4 : 16
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-heading)",
      fontSize: "var(--text-ui-15)",
      fontWeight: 500
    }
  }, title), action) : null, description ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 16px",
      fontSize: "var(--text-ui-13)",
      color: "var(--panel-surface-fg-muted)",
      lineHeight: 1.5
    }
  }, description) : null, children, footer ? /*#__PURE__*/React.createElement("footer", {
    style: {
      marginTop: 16
    }
  }, footer) : null);
}
Object.assign(__ds_scope, { SectionCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/SectionCard.jsx", error: String((e && e.message) || e) }); }

// components/product/Wordmark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Type-only lockup. This design system deliberately ships NO logo mark — the
   source project's mark belongs to its owners. Set `name` to your product and
   drop in your own <img> via `mark` once you have one. */
function Wordmark({
  name = "Product",
  mark,
  height = 22,
  showBeta = false,
  className = "",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      ...style
    }
  }, rest), mark ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      height,
      flexShrink: 0
    }
  }, mark) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-heading)",
      fontSize: height * 0.82,
      fontWeight: 600,
      lineHeight: 1,
      letterSpacing: "-0.01em",
      color: "inherit"
    }
  }, name), showBeta ? /*#__PURE__*/React.createElement("span", {
    style: {
      border: "1px solid var(--nav-beta-border)",
      borderRadius: 9999,
      padding: "1px 6px",
      fontSize: "var(--text-ui-9)",
      fontWeight: 600,
      letterSpacing: "0.06em",
      color: "var(--nav-fg-muted)"
    }
  }, "BETA") : null);
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/Wordmark.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/ChatScreen.jsx
try { (() => {
const {
  Composer,
  ComposerPill,
  Button,
  Icon,
  Badge,
  Avatar,
  Tooltip,
  SegmentedControl,
  Select
} = window.DS;
const SUGGESTIONS = [{
  icon: "graduation-cap",
  label: "Fine-tune a model on my data"
}, {
  icon: "file-text",
  label: "Build a dataset from PDFs"
}, {
  icon: "package",
  label: "Export to GGUF"
}, {
  icon: "terminal",
  label: "Serve an OpenAI-compatible API"
}];
function ModelPill({
  children,
  icon
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      height: 30,
      padding: "0 10px",
      border: 0,
      borderRadius: 9999,
      background: "color-mix(in srgb, var(--foreground) 5%, transparent)",
      fontFamily: "inherit",
      fontSize: "var(--text-ui-12p5)",
      fontWeight: 500,
      color: "var(--foreground)",
      cursor: "pointer"
    }
  }, icon, /*#__PURE__*/React.createElement("span", null, children), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 13
  }));
}
function ChatScreen({
  messages,
  onSend
}) {
  const [draft, setDraft] = React.useState("");
  const empty = messages.length === 0;
  const composer = /*#__PURE__*/React.createElement(Composer, {
    value: draft,
    onValueChange: setDraft,
    placeholder: "Ask anything",
    pills: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Tooltip, {
      label: "Attach files"
    }, /*#__PURE__*/React.createElement(ComposerPill, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "plus",
        size: 15
      })
    })), /*#__PURE__*/React.createElement(ComposerPill, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "globe",
        size: 15
      }),
      label: "Search",
      active: true
    }), /*#__PURE__*/React.createElement(ComposerPill, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "library",
        size: 15
      }),
      label: "RAG"
    }), /*#__PURE__*/React.createElement(ComposerPill, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "shield-check",
        size: 15
      }),
      label: "Ask"
    }), /*#__PURE__*/React.createElement(ComposerPill, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "zap",
        size: 15
      }),
      label: "Bypass",
      variant: "danger"
    })),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "icon-sm",
      "aria-label": "Dictate"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "mic",
      size: 15
    })), /*#__PURE__*/React.createElement(Button, {
      size: "icon-sm",
      "aria-label": "Send",
      onClick: () => {
        if (draft.trim()) {
          onSend(draft.trim());
          setDraft("");
        }
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up",
      size: 15
    })))
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(TitleBar, {
    title: "Chat",
    right: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(ModelPill, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "box",
        size: 14
      })
    }, "qwen3.8-8b-gguf \xB7 Q4_K_M"), /*#__PURE__*/React.createElement(Tooltip, {
      label: "Compare"
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "icon-sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "columns-2",
      size: 15
    }))), /*#__PURE__*/React.createElement(Tooltip, {
      label: "Run settings"
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "icon-sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "sliders-horizontal",
      size: 15
    }))))
  }), empty ? /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "0 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "0 0 26px",
      fontFamily: "var(--font-heading)",
      fontSize: "var(--text-ui-30)",
      fontWeight: 500
    }
  }, "Good evening, Daniel"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: 720
    }
  }, composer), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      justifyContent: "center",
      gap: 8,
      marginTop: 18,
      maxWidth: 720
    }
  }, SUGGESTIONS.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.label,
    type: "button",
    onClick: () => onSend(s.label),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 7,
      height: 32,
      padding: "0 13px",
      border: "1px solid var(--border)",
      borderRadius: 9999,
      background: "transparent",
      fontFamily: "inherit",
      fontSize: "var(--text-ui-12p5)",
      color: "var(--panel-surface-fg-muted)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: s.icon,
    size: 14
  }), s.label)))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "8px 0 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      margin: "0 auto",
      display: "flex",
      flexDirection: "column",
      gap: 26
    }
  }, messages.map((m, i) => m.role === "user" ? /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "flex-end"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "78%",
      padding: "10px 16px",
      borderRadius: 22,
      background: "var(--accent)",
      color: "var(--accent-foreground)",
      fontSize: "var(--text-ui-15)",
      lineHeight: 1.55
    }
  }, m.text)) : /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-ui-15)",
      lineHeight: 1.62,
      whiteSpace: "pre-wrap"
    }
  }, m.text), m.code ? /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-xl)",
      overflow: "hidden",
      background: "var(--code-block)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "7px 12px",
      fontSize: "var(--text-ui-11)",
      color: "#9b9b9b",
      fontFamily: "var(--font-mono)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "bash"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "copy",
    size: 13,
    color: "#9b9b9b"
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "download",
    size: 13,
    color: "#9b9b9b"
  })), /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: 0,
      padding: "4px 14px 14px",
      fontFamily: "var(--font-mono)",
      fontSize: 12.5,
      lineHeight: 1.7,
      color: "#ececec",
      overflowX: "auto"
    }
  }, m.code)) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 2,
      marginLeft: -8,
      color: "var(--chat-icon-fg)"
    }
  }, ["copy", "thumbs-up", "thumbs-down", "refresh-cw"].map(n => /*#__PURE__*/React.createElement(Button, {
    key: n,
    variant: "ghost",
    size: "icon-sm",
    "aria-label": n
  }, /*#__PURE__*/React.createElement(Icon, {
    name: n,
    size: 15
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 8,
      fontSize: "var(--text-ui-11)",
      color: "var(--panel-surface-fg-muted)",
      fontVariantNumeric: "tabular-nums"
    }
  }, "1,284 tok \xB7 41.2 tok/s")))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 24px 20px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      margin: "0 auto"
    }
  }, composer))));
}
Object.assign(window, {
  ChatScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/ChatScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/HubScreen.jsx
try { (() => {
const {
  ModelRow,
  SegmentedControl,
  InputGroup,
  Input,
  Button,
  Icon,
  Badge,
  Select,
  Tooltip,
  Progress,
  Separator
} = window.DS;
const MODELS = [{
  logo: "Q",
  name: "qwen3.8-8b-gguf",
  owner: "Qwen",
  meta: "1.2M downloads · 256K context",
  tags: [{
    label: "Q4_K_M"
  }],
  size: "4.9 GB",
  verified: true,
  local: true
}, {
  logo: "G",
  name: "gemma-4-e2b-it-gguf",
  owner: "Google",
  meta: "842K downloads · 128K context",
  tags: [{
    label: "Q8_0"
  }],
  size: "2.1 GB",
  verified: true,
  local: true
}, {
  logo: "D",
  name: "deepseek-v4-flash-gguf",
  owner: "DeepSeek",
  meta: "410K downloads",
  tags: [{
    label: "OOM",
    variant: "destructive"
  }],
  size: "41 GB",
  verified: true
}, {
  logo: "L",
  name: "llama-3.1-8b-instruct",
  owner: "Meta",
  meta: "3.4M downloads · 128K context",
  tags: [{
    label: "Tight",
    variant: "outline"
  }],
  size: "16 GB",
  verified: true
}, {
  logo: "M",
  name: "ministral-3-vl-3b",
  owner: "Mistral",
  meta: "96K downloads · vision",
  tags: [{
    label: "NVFP4"
  }],
  size: "3.2 GB",
  verified: true
}, {
  logo: "O",
  name: "gpt-oss-20b-gguf",
  owner: "OpenAI",
  meta: "1.9M downloads",
  tags: [{
    label: "Q4_K_XL"
  }],
  size: "12 GB",
  verified: true
}, {
  logo: "P",
  name: "phi-4-mini-instruct",
  owner: "Microsoft",
  meta: "220K downloads",
  tags: [{
    label: "FP8"
  }],
  size: "7.6 GB"
}, {
  logo: "N",
  name: "nemotron-4b-reason",
  owner: "NVIDIA",
  meta: "64K downloads",
  tags: [{
    label: "Q5_K_M"
  }],
  size: "3.1 GB"
}];
function HubScreen() {
  const [source, setSource] = React.useState("hf");
  const [scope, setScope] = React.useState("curated");
  const [selected, setSelected] = React.useState(MODELS[1].name);
  const rows = source === "device" ? MODELS.filter(m => m.local) : MODELS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(TitleBar, {
    title: "Model hub",
    subtitle: "Browse, download and load models",
    right: /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "folder-open",
      size: 14
    }), "Models folder")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "4px 16px 14px",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(InputGroup, {
    leading: /*#__PURE__*/React.createElement(Icon, {
      name: "search",
      size: 15
    })
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Search or paste a Hugging Face id...",
    style: {
      paddingLeft: 34
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 190,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: source,
    onValueChange: setSource,
    ariaLabel: "Model source",
    options: [{
      value: "device",
      label: "On Device"
    }, {
      value: "hf",
      label: "Hugging Face"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 150,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: scope,
    onValueChange: setScope,
    ariaLabel: "Hub section",
    options: [{
      value: "curated",
      label: "Curated"
    }, {
      value: "all",
      label: "All"
    }]
  })), /*#__PURE__*/React.createElement(Select, {
    defaultValue: "recent",
    options: [{
      value: "recent",
      label: "Recent"
    }, {
      value: "name",
      label: "Name"
    }, {
      value: "size",
      label: "Size"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "0 12px 16px"
    }
  }, rows.map(m => /*#__PURE__*/React.createElement(ModelRow, {
    key: m.name,
    logo: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 600,
        color: "var(--panel-surface-fg-muted)"
      }
    }, m.logo),
    name: m.name,
    owner: m.owner,
    meta: m.meta,
    tags: m.tags,
    size: m.size,
    verified: m.verified,
    selected: selected === m.name,
    onClick: () => setSelected(m.name),
    action: m.local ? /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      size: "xs"
    }, "Load") : /*#__PURE__*/React.createElement(Tooltip, {
      label: "Download"
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "icon-sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 15
    })))
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      padding: "10px 16px 14px",
      borderTop: "1px solid var(--border)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      fontSize: "var(--text-ui-12)",
      color: "var(--panel-surface-fg-muted)",
      marginBottom: 7
    }
  }, /*#__PURE__*/React.createElement("span", null, "Downloading deepseek-v4-flash-gguf"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: "tabular-nums"
    }
  }, "26.4 / 41 GB \xB7 64%")), /*#__PURE__*/React.createElement(Progress, {
    value: 64,
    style: {
      height: 8
    }
  })));
}
Object.assign(window, {
  HubScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/HubScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/LoginScreen.jsx
try { (() => {
const {
  Input,
  Label,
  Button,
  Icon,
  Wordmark,
  Alert,
  Terminal
} = window.DS;
function LoginScreen({
  onSubmit
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      height: "100%",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 22,
      width: "100%",
      maxWidth: 360
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    name: "Studio",
    height: 30,
    showBeta: true
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-13)",
      color: "var(--panel-surface-fg-muted)"
    }
  }, "Running locally on port 8888")), /*#__PURE__*/React.createElement("div", {
    className: "elevated-card",
    style: {
      width: "100%",
      padding: 22,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Label, {
    htmlFor: "pw"
  }, "Admin password"), /*#__PURE__*/React.createElement(Input, {
    id: "pw",
    type: "password",
    defaultValue: "studio-local"
  })), /*#__PURE__*/React.createElement(Button, {
    onClick: onSubmit
  }, "Unlock"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-12)",
      color: "var(--panel-surface-fg-muted)",
      lineHeight: 1.5,
      textAlign: "center"
    }
  }, "Rotate it later with ", /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "0.95em"
    }
  }, "studio reset-password"), "."))));
}
Object.assign(window, {
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/RunScreen.jsx
try { (() => {
const {
  Tabs,
  SectionCard,
  Button,
  Icon,
  Badge,
  StatRow,
  Terminal,
  Progress,
  Separator,
  Table
} = window.DS;
const LOG = [{
  text: "Trainer 2026.8.1 · fast Qwen3 patching · Transformers 4.61.0",
  tone: "success"
}, {
  text: "NVIDIA GeForce RTX 4090 · num GPUs = 1 · max memory 23.988 GB",
  tone: "muted"
}, {
  text: "Torch 2.9.1 · CUDA 8.9 · toolkit 12.8 · Triton 3.5.0",
  tone: "muted"
}, {
  text: "bfloat16 = TRUE · FA2 = TRUE · padding-free + packing = TRUE",
  tone: "muted"
}, {
  text: ""
}, {
  text: "Loading qwen3.8-8b in 4-bit ... done (11.2s)"
}, {
  text: "Dataset support-tickets-2k · 2,041 rows · packing to 2,048 tokens"
}, {
  text: "LoRA rank 32, alpha 32, targeting 7 modules · 41.9M trainable (0.52%)"
}, {
  text: ""
}, {
  text: "  step  loss    grad_norm  lr        s/it",
  tone: "muted"
}, {
  text: "    10  1.4821  0.9142     2.00e-04  1.31"
}, {
  text: "    20  1.1094  0.7318     1.62e-04  1.29"
}, {
  text: "    30  0.9642  0.6104     1.15e-04  1.28"
}, {
  text: "    40  0.8811  0.5522     6.90e-05  1.30"
}, {
  text: "Saving checkpoint-40 to outputs/qwen3.8-tickets ..."
}];
function LossChart() {
  const points = [1.48, 1.31, 1.19, 1.11, 1.04, 0.99, 0.96, 0.93, 0.9, 0.88];
  const w = 100,
    h = 100,
    min = 0.8,
    max = 1.55;
  const path = points.map((v, i) => {
    const x = i / (points.length - 1) * w;
    const y = h - (v - min) / (max - min) * h;
    return `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`;
  }).join(" ");
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 100",
    preserveAspectRatio: "none",
    style: {
      width: "100%",
      height: 116,
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: `${path} L100,100 L0,100 Z`,
    fill: "var(--chart-1)",
    opacity: "0.12"
  }), /*#__PURE__*/React.createElement("path", {
    d: path,
    fill: "none",
    stroke: "var(--chart-1)",
    strokeWidth: "1.6",
    vectorEffect: "non-scaling-stroke",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }));
}
function RunScreen({
  onStop
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(TitleBar, {
    title: "Train",
    subtitle: "Training in progress",
    right: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      variant: "accent"
    }, "Running"), /*#__PURE__*/React.createElement(Button, {
      variant: "destructive",
      size: "sm",
      onClick: onStop
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "square",
      size: 14
    }), "Stop run"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 16px 10px",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    defaultValue: "run",
    tabs: [{
      value: "configure",
      label: "Configure"
    }, {
      value: "run",
      label: "Current Run"
    }, {
      value: "history",
      label: "History"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "6px 16px 20px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,1fr) 320px",
      gap: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(SectionCard, {
    title: "Progress"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: "var(--text-ui-12p5)",
      color: "var(--panel-surface-fg-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "Step 42 of 60 \xB7 epoch 0.7"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: "tabular-nums"
    }
  }, "23s remaining")), /*#__PURE__*/React.createElement(Progress, {
    value: 70
  }), /*#__PURE__*/React.createElement(Separator, null), /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Loss",
      value: "0.8811"
    }, {
      label: "Grad norm",
      value: "0.552"
    }, {
      label: "LR",
      value: "6.90e-05"
    }, {
      label: "s/it",
      value: "1.30"
    }, {
      label: "VRAM",
      value: "11.4 / 24 GB"
    }]
  }))), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Training loss"
  }, /*#__PURE__*/React.createElement(LossChart, null)), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Logs",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "icon-sm",
      "aria-label": "Copy logs"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "copy",
      size: 15
    }))
  }, /*#__PURE__*/React.createElement(Terminal, {
    lines: LOG,
    style: {
      maxHeight: 300,
      fontSize: 11.5,
      lineHeight: 1.55
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(SectionCard, {
    title: "Run"
  }, /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Model",
      value: "qwen3.8-8b"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8
    }
  }), /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Method",
      value: "QLoRA · 4-bit"
    }, {
      label: "Rank",
      value: 32
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8
    }
  }), /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Dataset",
      value: "support-tickets-2k"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8
    }
  }), /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Started",
      value: "18:42"
    }, {
      label: "Elapsed",
      value: "1m 08s"
    }]
  })), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Checkpoints"
  }, /*#__PURE__*/React.createElement(Table, {
    columns: [{
      key: "name",
      header: "Name"
    }, {
      key: "step",
      header: "Step",
      align: "right"
    }],
    rows: [{
      name: "checkpoint-40",
      step: "40"
    }, {
      name: "checkpoint-20",
      step: "20"
    }]
  })), /*#__PURE__*/React.createElement(SectionCard, {
    title: "After training"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "package",
    size: 14
  }), "Export to GGUF"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "message-square",
    size: 14
  }), "Chat with the adapter")))))));
}
Object.assign(window, {
  RunScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/RunScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/SettingsScreen.jsx
try { (() => {
const {
  Tabs,
  SectionCard,
  Field,
  Switch,
  Select,
  Slider,
  Input,
  Button,
  Icon,
  Badge,
  Separator,
  Label,
  SegmentedControl
} = window.DS;
function PaletteCard({
  value,
  label,
  active,
  onSelect
}) {
  const swatches = value === "standard" ? ["#fefefd", "#339cff", "#ececec"] : value === "classic" ? ["#ffffff", "#0d0d0d", "#339cff"] : ["#ffffff", "#171717", "#ebebeb"];
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => onSelect(value),
    className: "palette-card",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 9,
      padding: 11,
      cursor: "pointer",
      border: `1px solid ${active ? "var(--ring-select)" : "var(--border)"}`,
      borderRadius: "var(--radius-xl)",
      background: "var(--card)",
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 5
    }
  }, swatches.map(c => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      width: 26,
      height: 26,
      borderRadius: 9999,
      background: c,
      boxShadow: "inset 0 0 0 1px rgba(0,0,0,.08)"
    }
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-12p5)",
      fontWeight: 500
    }
  }, label));
}
function SettingsScreen() {
  const [palette, setPalette] = React.useState("standard");
  const [dark, setDark] = React.useState(false);
  React.useEffect(() => {
    const root = document.documentElement;
    if (palette === "standard") root.removeAttribute("data-palette");else root.setAttribute("data-palette", palette);
  }, [palette]);
  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(TitleBar, {
    title: "Settings",
    right: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "icon-sm",
      "aria-label": "Close"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "x",
      size: 16
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 16px 10px",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    defaultValue: "appearance",
    tabs: [{
      value: "general",
      label: "General"
    }, {
      value: "appearance",
      label: "Appearance"
    }, {
      value: "system",
      label: "System"
    }, {
      value: "security",
      label: "Security"
    }, {
      value: "about",
      label: "About"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "6px 16px 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 680,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(SectionCard, {
    title: "Theme"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "Dark mode",
    hint: "Surfaces are shared across every palette in dark mode."
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: dark,
    onCheckedChange: setDark
  })), /*#__PURE__*/React.createElement(Separator, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Colour palette"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(PaletteCard, {
    value: "standard",
    label: "Standard",
    active: palette === "standard",
    onSelect: setPalette
  }), /*#__PURE__*/React.createElement(PaletteCard, {
    value: "classic",
    label: "Classic",
    active: palette === "classic",
    onSelect: setPalette
  }), /*#__PURE__*/React.createElement(PaletteCard, {
    value: "minimal",
    label: "Minimal",
    active: palette === "minimal",
    onSelect: setPalette
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-12)",
      color: "var(--panel-surface-fg-muted)"
    }
  }, "The palette is a second theming dimension, orthogonal to light and dark.")))), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Text and icons"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "UI font size",
    hint: "Every size token multiplies by this scale; layout stays put."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 200
    }
  }, /*#__PURE__*/React.createElement(Slider, {
    defaultValue: 15,
    min: 12,
    max: 20
  }))), /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "Contrast"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 200
    }
  }, /*#__PURE__*/React.createElement(Slider, {
    defaultValue: 50
  }))), /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "Font smoothing"
  }, /*#__PURE__*/React.createElement(Switch, {
    defaultChecked: true
  })), /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "Pointer cursors",
    hint: "Show a hand cursor over interactive elements."
  }, /*#__PURE__*/React.createElement(Switch, {
    defaultChecked: true
  })), /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "Reduce motion",
    hint: "Collapses CSS animations app-wide. Loaders keep spinning."
  }, /*#__PURE__*/React.createElement(Switch, null)))), /*#__PURE__*/React.createElement(SectionCard, {
    title: "System"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "GGUF inference engine",
    hint: "Only backends with a build for this machine are listed."
  }, /*#__PURE__*/React.createElement(Select, {
    defaultValue: "cuda",
    options: [{
      value: "auto",
      label: "Automatic"
    }, {
      value: "cpu",
      label: "CPU"
    }, {
      value: "cuda",
      label: "CUDA"
    }, {
      value: "rocm",
      label: "ROCm"
    }, {
      value: "vulkan",
      label: "Vulkan"
    }]
  })), /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "Hugging Face token",
    hint: "Required for gated or private models and datasets."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "secondary"
  }, "Saved"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm"
  }, "Replace"))), /*#__PURE__*/React.createElement(Field, {
    orientation: "horizontal",
    label: "CPU thread cap"
  }, /*#__PURE__*/React.createElement(Input, {
    type: "number",
    defaultValue: "8",
    style: {
      width: 110
    }
  })))))));
}
Object.assign(window, {
  SettingsScreen,
  PaletteCard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/SettingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/Shell.jsx
try { (() => {
const {
  Sidebar,
  SidebarGroup,
  NavRow,
  Badge,
  Avatar,
  Icon,
  Wordmark,
  Button,
  Tooltip,
  Separator,
  Menu
} = window.DS;
function TitleBar({
  title,
  subtitle,
  right
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      height: 52,
      padding: "0 16px",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-heading)",
      fontSize: "var(--text-ui-15)",
      fontWeight: 500
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-11p5)",
      color: "var(--panel-surface-fg-muted)"
    }
  }, subtitle) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), right);
}
const NAV = [{
  id: "chat",
  icon: "message-square",
  label: "New chat"
}, {
  id: "search",
  icon: "search",
  label: "Search"
}, {
  id: "projects",
  icon: "folder",
  label: "Projects"
}, {
  id: "hub",
  icon: "box",
  label: "Model hub"
}, {
  id: "train",
  icon: "graduation-cap",
  label: "Train",
  badge: "New"
}, {
  id: "recipes",
  icon: "beaker",
  label: "Recipes"
}, {
  id: "images",
  icon: "image",
  label: "Images"
}, {
  id: "audio",
  icon: "audio-lines",
  label: "Audio"
}, {
  id: "export",
  icon: "package",
  label: "Export"
}, {
  id: "api",
  icon: "terminal",
  label: "API"
}];
const RECENTS = ["Fine-tune Gemma 4 on support tickets", "GGUF export sizes compared", "Why is my LoRA loss flat?", "Set up MCP filesystem server"];
function AppSidebar({
  screen,
  onNavigate
}) {
  return /*#__PURE__*/React.createElement(Sidebar, {
    style: {
      flexShrink: 0
    },
    header: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "2px 8px 8px"
      }
    }, /*#__PURE__*/React.createElement(Wordmark, {
      name: "Studio",
      height: 19,
      showBeta: true
    })), /*#__PURE__*/React.createElement(NavRow, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "plus"
      }),
      label: "New chat",
      active: screen === "chat",
      onClick: () => onNavigate("chat")
    }), /*#__PURE__*/React.createElement(NavRow, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "search"
      }),
      label: "Search"
    })),
    footer: /*#__PURE__*/React.createElement(Menu, {
      align: "start",
      trigger: /*#__PURE__*/React.createElement(NavRow, {
        icon: /*#__PURE__*/React.createElement(Avatar, {
          size: "sm",
          fallback: "DH"
        }),
        label: "Daniel",
        trailing: /*#__PURE__*/React.createElement(Icon, {
          name: "chevron-up",
          size: 14
        })
      }),
      items: [{
        label: "Settings",
        icon: /*#__PURE__*/React.createElement(Icon, {
          name: "settings",
          size: 15
        }),
        onSelect: () => onNavigate("settings")
      }, {
        label: "Dark Mode",
        icon: /*#__PURE__*/React.createElement(Icon, {
          name: "moon",
          size: 15
        }),
        onSelect: () => document.documentElement.classList.toggle("dark")
      }, {
        label: "Guided Tour",
        icon: /*#__PURE__*/React.createElement(Icon, {
          name: "compass",
          size: 15
        })
      }, {
        label: "Help",
        icon: /*#__PURE__*/React.createElement(Icon, {
          name: "life-buoy",
          size: 15
        })
      }, {
        type: "separator"
      }, {
        label: "Log out",
        icon: /*#__PURE__*/React.createElement(Icon, {
          name: "log-out",
          size: 15
        })
      }, {
        label: "Shutdown",
        icon: /*#__PURE__*/React.createElement(Icon, {
          name: "power",
          size: 15
        }),
        variant: "destructive",
        onSelect: () => onNavigate("login")
      }]
    })
  }, /*#__PURE__*/React.createElement(SidebarGroup, null, NAV.slice(2).map(item => /*#__PURE__*/React.createElement(NavRow, {
    key: item.id,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: item.icon
    }),
    label: item.label,
    active: screen === item.id,
    badge: item.badge ? /*#__PURE__*/React.createElement(Badge, {
      variant: "accent"
    }, item.badge) : null,
    onClick: () => onNavigate(item.id)
  })), /*#__PURE__*/React.createElement(NavRow, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "more-horizontal"
    }),
    label: "More"
  })), /*#__PURE__*/React.createElement(SidebarGroup, {
    label: "Recents"
  }, RECENTS.map(title => /*#__PURE__*/React.createElement(NavRow, {
    key: title,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "message-square"
    }),
    label: title
  })), /*#__PURE__*/React.createElement(NavRow, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "chevron-down"
    }),
    label: "Show more"
  })));
}
Object.assign(window, {
  TitleBar,
  AppSidebar,
  NAV,
  RECENTS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/TrainScreen.jsx
try { (() => {
const {
  Tabs,
  SectionCard,
  Field,
  Label,
  Input,
  Select,
  RadioGroup,
  Slider,
  Switch,
  Button,
  Icon,
  Badge,
  StatRow,
  Alert,
  InfoHint,
  Separator,
  Accordion
} = window.DS;
const STEPS = [{
  n: 1,
  title: "Model",
  description: "Select model and training method"
}, {
  n: 2,
  title: "Dataset",
  description: "Select or upload training data"
}, {
  n: 3,
  title: "Parameters",
  description: "Configure training parameters"
}, {
  n: 4,
  title: "Configuration",
  description: "Save and load configurations"
}];
function StepHead({
  step,
  active
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 22,
      height: 22,
      borderRadius: 9999,
      background: active ? "var(--primary)" : "var(--muted)",
      color: active ? "var(--primary-foreground)" : "var(--muted-foreground)",
      fontSize: "var(--text-ui-11)",
      fontWeight: 600,
      flexShrink: 0
    }
  }, step.n), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-heading)",
      fontSize: "var(--text-ui-15)",
      fontWeight: 500
    }
  }, step.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-ui-11p5)",
      color: "var(--panel-surface-fg-muted)"
    }
  }, step.description)));
}
function TrainScreen({
  onStart
}) {
  const [method, setMethod] = React.useState("qlora");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(TitleBar, {
    title: "Train",
    subtitle: "Configure and start training",
    right: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm"
    }, "Load YAML"), /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      size: "sm"
    }, "Save YAML"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 16px 10px",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    defaultValue: "configure",
    tabs: [{
      value: "configure",
      label: "Configure"
    }, {
      value: "run",
      label: "Current Run"
    }, {
      value: "history",
      label: "History"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "6px 16px 20px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,1fr) 320px",
      gap: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(SectionCard, {
    title: /*#__PURE__*/React.createElement(StepHead, {
      step: STEPS[0],
      active: true
    })
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Model ", /*#__PURE__*/React.createElement(InfoHint, {
    label: "The base model you want to fine-tune."
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Input, {
    defaultValue: "qwen3.8-8b",
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "default"
  }, "Browse"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Method ", /*#__PURE__*/React.createElement(InfoHint, {
    label: "How the model is trained. LoRA and QLoRA update small adapters instead of every weight."
  })), /*#__PURE__*/React.createElement(RadioGroup, {
    value: method,
    onValueChange: setMethod,
    options: [{
      value: "qlora",
      label: "QLoRA",
      hint: "4-bit quantization. Lowest VRAM, fastest to start."
    }, {
      value: "lora",
      label: "LoRA",
      hint: "16-bit adapters. Balanced quality and memory."
    }, {
      value: "full",
      label: "Full fine-tune",
      hint: "Trains all weights. Highest quality, needs the most VRAM."
    }, {
      value: "cpt",
      label: "Continued pretraining",
      hint: "Continued pretraining for new domains or languages."
    }]
  })))), /*#__PURE__*/React.createElement(SectionCard, {
    title: /*#__PURE__*/React.createElement(StepHead, {
      step: STEPS[1]
    })
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Input, {
    defaultValue: "support-tickets-2k",
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "outline"
  }, "Browse")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Subset"), /*#__PURE__*/React.createElement(Select, {
    defaultValue: "default",
    options: [{
      value: "default",
      label: "default"
    }],
    style: {
      width: "100%"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Train Split"), /*#__PURE__*/React.createElement(Select, {
    defaultValue: "train",
    options: [{
      value: "train",
      label: "train"
    }],
    style: {
      width: "100%"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Evaluation Split"), /*#__PURE__*/React.createElement(Select, {
    defaultValue: "none",
    options: [{
      value: "none",
      label: "None"
    }, {
      value: "test",
      label: "test"
    }],
    style: {
      width: "100%"
    }
  }))), /*#__PURE__*/React.createElement(Alert, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "info"
    }),
    title: "Downloads on start",
    description: "This dataset is not on this device yet. Training will download it automatically."
  }))), /*#__PURE__*/React.createElement(SectionCard, {
    title: /*#__PURE__*/React.createElement(StepHead, {
      step: STEPS[2]
    })
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "14px 20px",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Epochs"), /*#__PURE__*/React.createElement(Input, {
    type: "number",
    defaultValue: "1"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Learning rate"), /*#__PURE__*/React.createElement(Input, {
    defaultValue: "2e-4"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Max sequence length"), /*#__PURE__*/React.createElement(Input, {
    type: "number",
    defaultValue: "2048"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Label, null, "Batch size"), /*#__PURE__*/React.createElement(Slider, {
    defaultValue: 2,
    min: 1,
    max: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(Accordion, {
    items: [{
      value: "adv",
      title: "Advanced settings",
      content: "Warmup steps, weight decay, gradient checkpointing, LoRA rank and alpha, optimizer and scheduler."
    }]
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(SectionCard, {
    title: "Run preview",
    action: /*#__PURE__*/React.createElement(Badge, {
      variant: "accent"
    }, "Ready")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Method",
      value: method === "qlora" ? "QLoRA · 4-bit" : method === "lora" ? "LoRA · 16-bit" : method === "full" ? "Full · fp16" : "CPT"
    }, {
      label: "Length",
      value: "2,048"
    }]
  }), /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Steps",
      value: 60
    }, {
      label: "Epochs",
      value: 1
    }, {
      label: "Batch",
      value: 2
    }]
  }), /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "LR",
      value: "2e-4"
    }, {
      label: "Context",
      value: "32K"
    }]
  }), /*#__PURE__*/React.createElement(Separator, null), /*#__PURE__*/React.createElement(StatRow, {
    items: [{
      label: "Hardware",
      value: "RTX 4090 · 24 GB"
    }, {
      label: "HF token",
      value: "Saved"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-ui-12)",
      color: "var(--panel-surface-fg-muted)",
      lineHeight: 1.5
    }
  }, "~11 GB VRAM estimated. Model and dataset download on start."), /*#__PURE__*/React.createElement(Button, {
    onClick: onStart
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "play",
    size: 15
  }), "Start training"))), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Files"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      fontSize: "var(--text-ui-12p5)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--panel-surface-fg-muted)"
    }
  }, "Model"), /*#__PURE__*/React.createElement("span", null, "Downloads on start")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--panel-surface-fg-muted)"
    }
  }, "Dataset"), /*#__PURE__*/React.createElement("span", null, "Downloads on start"))))))));
}
Object.assign(window, {
  TrainScreen,
  StepHead,
  STEPS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/TrainScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.AvatarGroup = __ds_scope.AvatarGroup;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardTitle = __ds_scope.CardTitle;

__ds_ns.CardDescription = __ds_scope.CardDescription;

__ds_ns.CardContent = __ds_scope.CardContent;

__ds_ns.CardFooter = __ds_scope.CardFooter;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Separator = __ds_scope.Separator;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Spinner = __ds_scope.Spinner;

__ds_ns.StatRow = __ds_scope.StatRow;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Empty = __ds_scope.Empty;

__ds_ns.InfoHint = __ds_scope.InfoHint;

__ds_ns.Progress = __ds_scope.Progress;

__ds_ns.Terminal = __ds_scope.Terminal;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.InputGroup = __ds_scope.InputGroup;

__ds_ns.Label = __ds_scope.Label;

__ds_ns.RadioGroup = __ds_scope.RadioGroup;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Toggle = __ds_scope.Toggle;

__ds_ns.ToggleGroup = __ds_scope.ToggleGroup;

__ds_ns.Breadcrumb = __ds_scope.Breadcrumb;

__ds_ns.NavRow = __ds_scope.NavRow;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Sidebar = __ds_scope.Sidebar;

__ds_ns.SidebarGroup = __ds_scope.SidebarGroup;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Menu = __ds_scope.Menu;

__ds_ns.Popover = __ds_scope.Popover;

__ds_ns.Composer = __ds_scope.Composer;

__ds_ns.ComposerPill = __ds_scope.ComposerPill;

__ds_ns.ModelRow = __ds_scope.ModelRow;

__ds_ns.SectionCard = __ds_scope.SectionCard;

__ds_ns.Wordmark = __ds_scope.Wordmark;

})();
