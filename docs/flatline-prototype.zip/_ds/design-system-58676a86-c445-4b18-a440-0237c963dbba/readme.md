# Unsloth Design System

A design system extracted from **Unsloth Studio**, the web UI and desktop app inside the [`unslothai/unsloth`](https://github.com/unslothai/unsloth) repository.

Everything here — every hex value, radius, font size, easing curve and component variant — was read out of `studio/frontend/`. Nothing was designed from scratch, and nothing was rounded to a "nicer" number.

---

## Sources

| Source | What was taken from it |
| --- | --- |
| [github.com/unslothai/unsloth](https://github.com/unslothai/unsloth) | The whole system. Read at commit tree `0575c27bd948` on `main` — see `github.md`. |
| `studio/frontend/src/index.css` (3,213 lines) | All colour, type, radius, shadow, motion and icon-size tokens; the three colour palettes; the composer / tooltip / segmented-pill / elevated-card surface recipes. |
| `studio/frontend/src/features/hub/hub.css` | The segmented-toggle track and sliding pill, catalog-row hover behaviour. |
| `studio/frontend/src/components/ui/*.tsx` (58 files) | The component inventory and every variant, size and state. |
| `studio/frontend/src/i18n/locales/en.ts` | Product copy — navigation labels, training-wizard strings, error and empty-state text. All UI copy in this system is verbatim from here. |
| `studio/frontend/public/fonts/` | The Hellix and Fira Code font files (the only binaries kept — see **No borrowed brand assets** below). |
| `README.md` (repo root) | Marketing and documentation copy for the website and docs UI kits. |
| `studio/src-tauri/tauri.conf.json` | Desktop-app shell facts (product name "Unsloth", overlay titlebar, traffic-light offset 14/26). |

**Read the repository yourself** if you are building something substantial. `index.css` in particular carries dozens of design decisions as inline comments explaining *why* a value is what it is — that reasoning is the most valuable thing in the project and this readme only summarises it.

---

## The product

Unsloth is a local AI toolchain. One sentence from the README does the work: *"Unsloth is the first desktop app to run and train models."*

It ships in three forms, all sharing this design system:

- **Unsloth Desktop** — a Tauri app wrapping the Studio frontend. The recommended path; no setup.
- **Unsloth Studio** — the same UI served in a browser (`unsloth studio -p 8888`), beta.
- **Unsloth Core** — the Python package, no UI.

Studio's surfaces, from the sidebar order in `en.ts`: New chat · Search · Projects · Model hub · Train · Recipes · Images · Video · Audio · Export · API · Settings.

Two products are recreated here plus two extrapolations — see **UI kits** below.

---

## CONTENT FUNDAMENTALS

How Unsloth writes. All examples below are real strings from the repo.

**Voice: a competent engineer telling you what will happen.** Flat, factual, unhurried. It states mechanics and consequences, never benefits.

> "The model files left this device, so training will download them again."
> "4-bit quantization. Lowest VRAM, fastest to start."
> "It fails closed (does not start) if the tunnel can't come up, so the raw port is never exposed."

**Casing.** Sentence case everywhere — buttons, labels, titles, menu items. `Start for free`, `Load YAML`, `Select model and training method`, `Reset to defaults`. The only uppercase in the entire product is the sidebar group label (10px, weight 600) and the outlined `BETA` pill.

**Person.** Second person for the user, and the *product* is the actor in system sentences — not "we".

> "Enter a valid Hugging Face dataset ID."  ·  "Training will download it automatically."  ·  "Update your token in Settings → General, then retry."

Never "we couldn't", always "Couldn't scan local models". Never "Oops" or "Something went wrong".

**Errors name the cause and the fix, in that order.**

> Title: "Hugging Face token rejected" → Body: "Update your token in Settings → General, then retry."
> Title: "Cached model no longer available" → Body: "The model files left this device, so training will download them again."

**Empty states always give the next move**, usually three options:

> "Nothing on this device yet. Download a dataset from the Hub, build one in Recipes, or upload a file."

**Field hints are one sentence with a full stop.** They explain the mechanism, not the value:

> "How the model is trained. LoRA and QLoRA update small adapters instead of every weight."
> "Select which split to use for evaluation. None means no evaluation during training."

**Conventions**
- Navigation paths use a right arrow: `Settings → General`, `Settings > System > GGUF inference engine`.
- Ellipses are three literal dots in loading text: `Loading...`, `Scanning local models…` (both appear; prefer `...`).
- Technical terms are never softened: QLoRA, GGUF, NVFP4, VRAM, adapters, quant, tok/s.
- Numbers are specific: "2x faster", "70% less VRAM", "~11GB VRAM (GPU: 24GB)". Never "much faster".
- Abbreviate inside stat strips ("LR", "s/it"), spell out in labels ("Learning rate").
- Titles are 1–4 words: "Run preview", "Advanced settings", "Files", "Hardware".

**Emoji.** Used in the GitHub README's section headings (⚡ ⭐ 🚀 📥 📒 🦥 💚) and nowhere in the product UI. Do not put emoji in app screens, and do not use them as icons. The sloth mascot PNGs are the illustration vocabulary instead.

**Brand strings.** The wordmark is lowercase `unsloth`; the product is `Unsloth`; the web UI is `Unsloth Studio`; the desktop app is `Unsloth Desktop`. The company is `Unsloth AI`.

---

## VISUAL FOUNDATIONS

### Colour

A **two-dimensional** theme: mode (light / `.dark`) × palette (Standard / `[data-palette="classic"]` / `[data-palette="minimal"]`). Six combinations, and all six ship.

- **Standard** (default) — `--primary: #339cff` light, `#4dabff` dark. A saturated blue. This is the brand. Light-mode neutrals carry a faint blue tint (hue 251) so surfaces sit *with* the accent rather than against it.
- **Classic** — primary goes neutral (`#0d0d0d` light, `#ececec` dark) and the blue reaches small controls only, through `--control-accent`. Nothing large is coloured at all; that separation is what distinguishes it from Standard. Enterprise-safe.
- **Minimal** — strictly black, white and grey.

Two rules make the palettes work, and both are easy to get wrong:

1. **Dark surfaces are shared.** All three palettes use `#181818` page / `#1f1f1f` sidebar / `#212121` card in dark. Palettes override *accents only* in dark mode.
2. **`--control-accent` exists so small controls can keep a hue when `--primary` goes neutral.** Switches, "New" badges and progress fills read `--control-accent`; buttons read `--primary`. In Standard they are the same token.

**Light-mode surfaces are the subtle part.** The page is `#fefefd` — a *slightly warm* off-white. The sidebar is pure `#ffffff`. That 1-step tone difference **is** the divider; there is no border between them. In dark it inverts (sidebar lighter than page) and the border is removed entirely.

**The primary is for primary controls only.** Every hover and active wash in the app is neutral grey (`--accent: #ececec`), never a tint of the accent. Getting this wrong is the fastest way to make something look off.

**`--verified: #17b88b` is pinned to this green in every palette and mode**, because it carries meaning (success / verified). It is a *status* colour, not a brand colour — which is why it survived the switch to a blue primary and stays green even in Minimal. Same idea for `--bypass` (`#c99d00` light, `#ffd60a` dark), which marks the bypass-permissions state.

**Semantic colour is always a tinted wash, never a fill.** Destructive buttons and badges are `destructive/10` (or `/20` in dark) with red *text*. Nothing here is solid red.

### Typography

- **Heading**: Hellix, falling back to Space Grotesk Variable. Always **weight 500**, tracking **0**. Never bold, never tightened.
- **Body**: Inter Variable.
- **Mono**: Fira Code Variable (logs, commands, paths, quant names).

The scale is authored against a 16px base and shipped at 15px, so **every size token multiplies by `--ui-font-scale` (0.9375)**. Users can change it in Settings and rem-based layout stays put.

The size ladder is unusually fine, with half-steps: `--text-ui-10p5`, `-11p5`, `-12p5`, `-13p5`, `-14p5`, `-15p5`. These are deliberate. Copy them exactly; do not snap to a 4px grid.

Hierarchy is carried by **tone, not size**. A section title is only 15px — the same size as body text — and reads as a title because of the heading face and weight 500. Muted secondary text (`--panel-surface-fg-muted: #777779`) does most of the work.

### Space, radius, elevation

`--spacing: 0.25rem`. Control heights are 24 / 32 / 36 / 40px (xs / sm / default / lg).

**`--radius` is `1.1rem` — 17.6px.** That is much larger than most systems, and named steps walk out from it by ±4px up to `--radius-4xl` (~33px). Cards are ~33px. The chat composer is a literal 32px. Buttons, inputs, badges and switches are full pills. The only nearly-square control in the system is the checkbox, at exactly 6px.

**The app is flat.** Every `--shadow-*` token in the source resolves to a zero-opacity shadow. Cards get a `ring` (`0 0 0 1px foreground/10`) rather than a border or a shadow; `.elevated-card` uses a hairline border at 60% `--border`. There is exactly **one real shadow** in the product:

```
0 2px 8px -2px rgba(0, 0, 0, 0.16)
```

It is on the chat composer, dropdown menus, and the sliding segmented pill — and **it disappears in dark mode** (`--shadow-soft: none`), where borders and surface tone do the separating instead.

### States

- **Hover** is the same colour at 80–85% opacity, or a neutral grey wash. Never a different hue, never a shadow lift.
- **Focus** recolours the element's own border to `--ring-soft` — a derived mix of foreground and border. There are **no focus rings** and no coloured focus outlines. Selected state uses the deeper `--ring-select`. Neither is ever pure black.
- **Press**: nothing, except the slider thumb (scale 0.95).
- **Disabled**: `opacity: 0.5` and `pointer-events: none`.
- In dark mode, inputs and outline buttons drop their border entirely and become `rgba(255,255,255,0.06)`, rising to `0.12` on focus.

### Motion

Three durations (100 / 150 / 200ms), two easing curves (Emil Kowalski's `ease-out-quart` and `ease-out-cubic`). That is the whole vocabulary.

Transitions are colour and opacity. Transforms appear in exactly four places: the sliding tab pill (a spring — stiffness 500, damping 35, mass 0.5), the sliding segmented pill (a 200ms translate), the slider thumb, and a 300ms `icon-pop`. Chevrons rotate 180°.

Reduced motion collapses everything app-wide — **except spinners and progress bars**, because freezing them removes the only signal that work is in flight.

### Transparency, blur, gradients

- Blur appears once: the sticky header on the marketing and docs surfaces uses `backdrop-filter: blur(12px)` over an 88–90% background.
- **Scrollbars are never the platform default.** Track transparent, thumb a translucent neutral wash (`oklch(0.5 0 0 / 0.16)` light, `oklch(0.67 0 0 / 0.5)` dark) whose alpha roughly triples on hover. The sidebar goes further: its thumb is fully hidden until you hover the rail.
- **Gradients are masks, not decoration.** The sidebar scroll list uses `mask-image: linear-gradient(...)` so rows dissolve under the pinned header, and a sticky `::after` gradient in the sidebar colour washes the last rows into the account footer. There are no decorative background gradients anywhere. No purple-blue hero gradients.
- Dark mode leans on translucent white (`rgba(255,255,255,0.06 / 0.11)`) for input fills rather than solid greys, so the same fill works on `#181818` and `#212121`.

### Imagery

**This system ships no imagery.** The source product uses an illustrated mascot (flat, rounded, on transparent backgrounds) on the chat greeting and in empty states, and third-party provider logos in list rows — none of it is included here, because none of it is yours (see below).

What the *structure* tells you, and what you should honour with your own art:

- There is **no photography anywhere**, and no stock imagery. If you add illustration, make it flat, rounded, warm and transparent-background — not gradient-heavy, not 3D-rendered.
- Illustration belongs in exactly two places: the **greeting state** and **empty states**. Never inside dense UI, never as a repeating pattern or texture.
- Row-level marks sit at 17–22px inside a **28px rounded slot on `--muted`**, and are never recoloured or tinted. `ModelRow`'s `logo` prop is that slot; a monogram is a perfectly good fill until you have marks.
- Anywhere a logo would go, `Wordmark` renders the product name in the heading face. That is a real lockup, not a placeholder.

### No borrowed brand assets

The Unsloth logo, the sloth mascot illustrations, and the third-party model/provider marks were **removed from this system on purpose** — they belong to their owners and are not yours to ship. What remains from the repo is the *design language*: tokens, geometry, component behaviour, copy conventions, and the two webfonts.

Every place a mark used to sit now uses type or a monogram:

| Was | Now |
| --- | --- |
| Unsloth logo PNGs | `Wordmark` — the product name in the heading face at weight 600, with an optional `mark` slot for yours |
| Sloth mascot in the chat greeting / login / empty states | nothing; the greeting is type only, and `Empty` uses a 40px icon |
| Provider logos in `ModelRow` and the marketing logo wall | single-letter monograms in `--muted`, and word marks on the logo wall |
| Favicon | none linked |

The placeholder product name throughout the kits is **"Studio"** — in copy, in commands (`studio serve -p 8888`, `studio start claude`), and in `SKILL.md`. Grep `ui_kits/` for `Studio` and `studio` to rename everything; placeholder URLs are `example.com`. Nothing in `ui_kits/` names the source project any more.

**On getting a real logo:** I can't produce one. I do not generate images, and hand-rolled SVG marks look exactly like hand-rolled SVG marks — you would be able to tell, and so would everyone else. Options that actually give you a high-quality mark:

1. **A designer or a brand studio.** For a product identity this is the honest answer; expect a mark, a wordmark, an icon grid and a favicon set.
2. **An image-generation model** (Midjourney, Ideogram, or an image-capable model in the Claude app) for exploration, then a designer or an illustrator to redraw the direction you like as clean vectors. AI output is a starting point, not a shippable mark.
3. **A logo marketplace / generator** if budget is the constraint — but check the licence carefully, and check the mark is not being sold to twenty other companies.

Give me the finished SVG or PNG and I will wire it through every surface, generate the favicon and app-icon sizes, and add a lockup card with clear-space and minimum-size rules. Until then `Wordmark` stands on its own and nothing is broken.

### Layout

- Sidebar 256px (`--sidebar-width`), collapsing to a 48px icon rail.
- Content panes are `--panel-surface`, which tracks `--background`; the right-hand parameters panel is distinguished from the left sidebar by its left border alone.
- Chat threads are capped at ~720px and centred.
- Sticky elements: sidebar header and account footer, the docs left nav and on-this-page rail, the Train screen's Run preview panel.
- **Scroll boundaries are fades, not lines.** The sidebar masks its top 14px once scrolled so rows dissolve under the pinned header, and a 40px sticky gradient in the sidebar colour washes the last rows into the account footer. `.list-scroll-fade` does the same for lists inside a panel, fading whichever edge has more content beyond it. Reach for these before reaching for a `Separator`.
- Data density is high but never cramped: rows are 36–40px with a 10px gap, and catalog rows are transparent at rest with **no borders** — hover paints `--panel-surface-hover`. Do not put each row in its own card.

---

## ICONOGRAPHY

**The source product uses [Hugeicons](https://hugeicons.com)** — declared in `components.json` as `"iconLibrary": "hugeicons"`, via `@hugeicons/core-free-icons` and `@hugeicons/react`. Stroke icons, `strokeWidth={2}`, default size 16px, driven by a single `--icon-size` token so one edit retunes every nav row, menu, action bar and code-block control. `lucide-react` is also a dependency and supplies a few glyphs (the spinner is Lucide's `Loader2Icon`).

**⚠️ Substitution — please confirm.** Hugeicons ships as JS icon data with no CDN sprite this environment can load, so the `Icon` component here renders **Lucide** names from Lucide's UMD build. Lucide is the closest match (same 24px grid, same 2px stroke, same rounded caps) and is already in the product's dependency tree, but the individual glyphs are not identical to Hugeicons'. **If you want exact parity, send me the Hugeicons set and I will swap it in.**

Other rules:
- Never fill icons; never mix stroke weights on one screen.
- Icons in nav rows sit at `--nav-icon-idle` (a light grey) at rest and jump to full foreground when active.
- Icon size follows the UI font size, but grows at *half* the rate above 16px so icons read slightly smaller than enlarged text.
- No icon font, no SVG sprite. No emoji as icons. No Unicode glyphs as icons — the one exception is the `→` in navigation-path copy.
- No third-party marks ship here. Where a provider logo would go, use a monogram or your own asset.

---

## What is in this folder

```
styles.css              the single entry point consumers link — @import lines only
tokens/                 fonts · colors · palettes · dark · typography · spacing · motion · base
components/             components.css + 7 groups of React primitives
guidelines/             20 foundation specimen cards
ui_kits/                studio · website · docs
assets/fonts/           Hellix SemiBold + Fira Code Variable (the only binaries)
thumbnail.html          project tile
SKILL.md                Agent Skills entry point
github.md               source-repo association for one-click sync
```

**Start here to see the themes:** `guidelines/palette-preview.html` puts the same screen in all six palette x mode combinations side by side. `ui_kits/studio/index.html` → Settings → Appearance switches them live on a real app.

### Components

Grouped by concern. Every one has a `.jsx`, a `.d.ts` props contract and a `.prompt.md` usage note; each directory has a `@dsCard` card showing its states.

- **core/** — `Button`, `Badge`, `Card` (+ `CardHeader`, `CardTitle`, `CardDescription`, `CardContent`, `CardFooter`), `Avatar` (+ `AvatarGroup`), `Separator`, `Skeleton`, `Spinner`, `Icon`
- **forms/** — `Input`, `Textarea`, `Label`, `Field`, `Checkbox`, `RadioGroup`, `Switch`, `Select`, `Slider`, `SegmentedControl`, `Toggle` (+ `ToggleGroup`), `InputGroup`
- **feedback/** — `Alert`, `Progress`, `Tooltip`, `Toast`, `Empty`, `InfoHint`, `Terminal`
- **overlay/** — `Dialog`, `Popover`, `Menu`, `Accordion`
- **navigation/** — `Sidebar` (+ `SidebarGroup`), `NavRow`, `Tabs`, `Breadcrumb`, `Pagination`
- **data/** — `Table`, `StatRow`
- **product/** — `Composer` (+ `ComposerPill`), `ModelRow`, `SectionCard`, `Wordmark`

**Intentional additions** (not one-to-one with a source file, added because consumers need them):

- `Icon` — a glyph wrapper. The product calls `<HugeiconsIcon icon={...} />` inline everywhere; a wrapper is needed so the substitution above lives in one place.
- `StatRow` — the label/value strip from Studio's Run preview. Real pattern, no dedicated source component.
- `Wordmark` — a type-only product lockup with an optional mark slot, so no surface has to hard-code a logo.
- `NavRow` / `Sidebar` — cosmetic stand-ins for the product's 173KB `app-sidebar.tsx` and its resizable `sidebar.tsx`, carrying the same geometry and states.

**Source families NOT built here.** The repo defines 58 files in `components/ui/`. These were left out, and why:

- *Decorative / MagicUI effects the product barely uses*: `animated-shiny-text`, `sparkles-text`, `shine-border`, `light-rays`, `confetti`, `animated-theme-toggler`.
- *Needs a charting library*: `chart` (Recharts). The Run screen's loss chart in the Studio kit is a hand-plotted SVG stand-in.
- *Needs a heavy dependency*: `calendar` (react-day-picker), `command`/`combobox` (cmdk), `data-table` (TanStack Table), `resizable`/`panel-resize-handle` (react-resizable-panels), `sonner` (represented by the simpler `Toast`).
- *Thin wrappers with no visual identity*: `aspect-ratio`, `collapsible`, `scroll-area`, `hover-card`, `copyable-error-chip`.
- *Menu variants of `Menu`*: `dropdown-menu`, `context-menu`, `menubar`, `navigation-menu` — one `Menu` covers the shared surface; ask if you need the variants split out.
- *Overlay variants of `Dialog`*: `alert-dialog`, `sheet`.

Tell me which of these you want and I will build them.

### UI kits

| Kit | What it is | Fidelity |
| --- | --- | --- |
| `ui_kits/studio/` | **Unsloth Studio** — the real product, web + desktop. Six interactive screens: Chat (greeting + live thread), Model hub, Train > Configure, Train > Current Run, Settings > Appearance, Login. Palette and dark-mode switches in Settings retheme everything live. | Recreation, read from source |
| `ui_kits/website/` | Marketing landing page. | **Extrapolation** — layout is this design system applied; copy is placeholder. No marketing-site source exists in the repo. |
| `ui_kits/docs/` | Documentation shell (left nav / article / on-this-page). | **Extrapolation** — the shell is this design system applied; the Install page content is placeholder. |

Each kit has its own README naming the exact source files it was built from.

---

## Deliberate departures from the source

Everything else in this system is the source's value. These are not:

- **The primary is blue (`#339cff` / `#4dabff`), not the source's green.** Changed on request. The blue is the one the source already ships in its Classic palette, so it is a real value from the same system rather than an invented hue, and it sits at nearly the same lightness as the green it replaced (OKLCH L 0.66 vs 0.68) — so every derived value (the 80% hover, the 10% wash, the chart ramp) keeps working unchanged. Light-mode neutrals were re-tinted from hue 169 (green) to 251 (blue) to match. `--verified` stayed green on purpose: it is a status colour.
- **No logo, mascot or third-party marks** — removed, see above.
- **Icons are Lucide, not Hugeicons** — a substitution, see ICONOGRAPHY.

## Known gaps

- **Hellix ships only SemiBold (600).** `index.css` declares Regular (400) and Medium (500) pointing at `.woff` files that are not committed to the repo. Those weights fall back to Space Grotesk Variable. **Send me the full Hellix family if you have a licence.**
- **Icons are Lucide, not Hugeicons** — see ICONOGRAPHY above.
- **Chat greeting and composer placeholder strings** are not in `en.ts` (they are built at runtime in `thread.tsx`, a 261KB file). "Good evening, Daniel" and "Ask anything" are plausible stand-ins, not verbatim strings.
- The **node-graph dataset builder**, image/video galleries, model-comparison split view, and MCP/provider connection dialogs are not recreated.
- Marketing site and docs site are extrapolations, as flagged above.
- **No logo, no mascot, no third-party marks** — deliberate, see above. Send me a logo and I will wire it in.
